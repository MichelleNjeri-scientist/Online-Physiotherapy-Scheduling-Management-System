document.addEventListener("DOMContentLoaded", function () {

  var modalBody = document.querySelector(".login-form");
  var submitBtn = modalBody.querySelector('input[type="submit"]');
  
  submitBtn.onclick = function (event) {
    event.preventDefault(); 
  
    if (document.getElementById("name").value == '' ||
          document.getElementById("email").value == '' ||
          document.getElementById("phone_number").value == '' ||
          document.getElementById("gender").value == '' ||
          document.getElementById("qualification").value == '' ||
          document.getElementById("registration_id").value == '' ||
          document.getElementById("password2").value == '' ||
          document.getElementById("address").value == '' ||
          document.getElementById("password").value == '') {
        alert("Please fill in all the required fields");
      } else {
        const now = new Date();
        if(validateEmail(document.getElementById("email").value) == false) {
          alert("Please enter a valid email");
        } else {
          if(document.querySelector("#password2").value !== document.querySelector("#password").value){
              alert("Password and Password Confirm have to be Similar!")
          }else if(validatePassword(document.querySelector("#password").value) == true) {
            if(validatePhoneNumber(document.querySelector("#phone_number").value) == true){
               
              // Validation passed, submit the form or perform further actions
              submit_add();
              //console.log('success') 
          }   
          }            
          
        }            
      }   
  };
  function validateEmail(emailID) {
      atpos = emailID.indexOf("@");
      dotpos = emailID.lastIndexOf(".");
      if (atpos < 1 || ( dotpos - atpos < 2 )) {
         return false;
      }
      return true;
  }
  
  function validatePhoneNumber(phone_number){
    const phonenumberRegex = /(0)[0-9]{9}/;
    if (!phonenumberRegex.test(phone_number)) {
      alert("Enter a correct Phone Number.");
      return false;
    }
    return true;   
}

  function validatePassword(password) {
  // Check for special characters
  const specialCharsRegex = /[!@#$%^&*(),.?":{}|<>]/;
  if (!specialCharsRegex.test(password)) {
    alert("Password must contain at least one special character.");
    return false;
  }
  
  // Check for at least one number
  const numberRegex = /\d/;
  if (!numberRegex.test(password)) {
    alert("Password must contain at least one number.");
    return false;
  }
  
  // Check for at least one uppercase letter
  const uppercaseRegex = /[A-Z]/;
  if (!uppercaseRegex.test(password)) {
    alert("Password must contain at least one uppercase letter.");
    return false;
  }
  
  // Check for at least one lowercase letter
  const lowercaseRegex = /[a-z]/;
  if (!lowercaseRegex.test(password)) {
    alert("Password must contain at least one lowercase letter.");
    return false;
  }
    
  
  // Check for minimum length of 8 characters
  if (password.length < 8) {
    alert("Password must be at least 8 characters long.");
    return false;
  }
  
  return true;
  }
  
  function submit_add(){
    var form = document.querySelector(".login-form form");
    var formData = new FormData(form);
    console.log(formData.get("name"));
    console.log(formData.get("email"));
    console.log(formData.get("phone_number"));
    console.log(formData.get("qualification"));
    console.log(formData.get("gender"));
    console.log(formData.get("registration_id"));
  
    data = {
      name: formData.get("name"),
      email: formData.get("email"),
      phone_number: formData.get("phone_number"),
      qualification: formData.get("qualification"),
      gender: formData.get("gender"),
      registration_id: formData.get("registration_id"),
      password: formData.get("password"),
      address: formData.get("address"),
    };
  
    var url = "//fizio-backend.local/users/physios";
    fetch(url, {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json; charset=UTF-8",
      },
    })
      .then((response) => response.json())
      .then(function (response) {
        if (response.data) {
          if (response.data == "success") {
            alert("Success! Physio has been added!");
            document.getElementById("name").value = '';
            document.getElementById("email").value = '';
            document.getElementById("phone_number").value = '';
            document.getElementById("qualification").value = '';
            document.getElementById("gender").value = '';
            document.getElementById("registration_id").value = '';
            document.getElementById("password").value = '';
            document.getElementById("address").value = '';
          }else{
            alert(response.message);
          } 
        } else {
          alert(response.message);
        }
  
        console.log(response);
      })
      .catch(function (error) {
        console.log(error);
      });    
  }
  });
  