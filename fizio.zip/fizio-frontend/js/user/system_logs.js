document.addEventListener("DOMContentLoaded", function() {
    
    // initialize page to 1
    var currentPage = 1;
  
    // load initial page of data
    loadData(currentPage);
  
    // listen for page change events
    document.addEventListener('click', function(e) {
      if (e.target && e.target.classList.contains('pagination-link')) {
        e.preventDefault();
        currentPage = e.target.dataset.page;
        loadData(currentPage);
      }
    });
    
  
    function loadData(page) {
      var user = JSON.parse(localStorage.getItem("user"));
      var user_id = user['id'];
  
      var url = '//fizio-backend.local/users/views/systemlogs?page=' + page;
      fetch(url)
        .then(response => response.json())
        .then(function(response) {
  
          // clear table body
          var tableBody = document.querySelector('#logsTable tbody');
          tableBody.innerHTML = '';
  
          // populate table body with data
          response.data.forEach(function(row) {
            var tableRow = document.createElement('tr');
  
            tableRow.innerHTML = '<td>' + row.identification + '</td>' + '<td>' + row.status + '</td>';
            tableBody.appendChild(tableRow);
          });
  
          // generate pagination links
          var paginationLinks = document.querySelector('#pagination');
          paginationLinks.innerHTML = '';
  
          if (currentPage > 1) {
            let previousPage = eval(currentPage) - eval(1);
            paginationLinks.innerHTML += '<a href="#" class="pagination-link" data-page="' + previousPage + '">&lt;</a>';
          }
  
          paginationLinks.innerHTML += '<a href="#" class="pagination-link active" data-page="' + currentPage + '">' + currentPage + '</a>';
          
          if (currentPage < response.totalPages) {
            let nextPage = eval(currentPage) + eval(1);
            paginationLinks.innerHTML += '<a href="#" class="pagination-link" data-page="' + nextPage + '">&gt;</a>';
          }
        })
        .catch(function(error) {
          console.log(error);
        });
    }
  
    const interval = setInterval(function() {
      // method to be executed;
      loadData(currentPage);
    }, 5000);
    
   //clearInterval(interval);
  });