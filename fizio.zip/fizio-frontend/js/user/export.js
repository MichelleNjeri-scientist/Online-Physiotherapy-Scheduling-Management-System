document.querySelector('.export').addEventListener('click', (e) =>{
    var user = JSON.parse(localStorage.getItem("user"));
    var patient_id = user['id'];
    window.open("//fizio-backend.local/users/patientexport?patient_id="+patient_id, '_blank');  
})