document.addEventListener("DOMContentLoaded", function() {
    
    // initialize page to 1
    var currentPage = 1;
  
    // load initial page of data
    loadData(currentPage);
  
    // listen for page change events
    document.addEventListener('click', function(e) {
      if (e.target && e.target.classList.contains('pagination-link')) {
        e.preventDefault();
        currentPage = e.target.dataset.page;
        loadData(currentPage);
      }
    });
    
  
    function loadData(page) {
      var user = JSON.parse(localStorage.getItem("user"));
      var user_id = user['id'];
  
      var url = '//fizio-backend.local/users/views/physios?page=' + page;
      fetch(url)
        .then(response => response.json())
        .then(function(response) {
  
          // clear table body
          var tableBody = document.querySelector('#physiosTable tbody');
          tableBody.innerHTML = '';
  
          // populate table body with data
          response.data.forEach(function(row) {
            var tableRow = document.createElement('tr');
            var gender = '';
            if(row.gender == 1){
              gender = 'Male';
            }else if(row.gender == 2){
              gender = 'Female';
            }
  
            tableRow.innerHTML = '<td>' + row.name + '</td>' + '<td>' + row.registration_id + '</td>' + '<td>' + row.phone_number + '</td>' + '<td>' + row.email + '</td>' + '<td>' + gender + '</td>' + '<td>' + row.qualification + '</td>' + '<td style="text-align:center"> <a href="#" class="btn edit-button"><ion-icon name="create-outline"></ion-icon></a></td> <td><a href="#" class="btn delete-button"><ion-icon name="trash-outline"></ion-icon></a></td>';
            tableRow.querySelector('.edit-button').addEventListener('click', function() {
              localStorage.removeItem("physio_id");
              localStorage.setItem("physio_id", row.physio_id);
              window.location.replace('/edit-physio.html');
            });
            tableRow.querySelector('.delete-button').addEventListener('click', function() {
              let data = {
                physio_id: row.physio_id,
              }; 
            fetch("//fizio-backend.local/users/physiodelete", {
              method: "POST",
              body: JSON.stringify(data),
              headers: {
                "Content-Type": "application/json; charset=UTF-8",
              },
            })
              .then((response) => response.json())
              .then((data) => {
                console.log(data);
                if (data.data == "success") {
                  alert("The physio has been deleted successfully.");
                } else if(data.data == "failed") {
                  alert("The physio was not deleted.");
                }
                loadData(currentPage);
              })
              .catch((error) => {
                console.error("Error:", error.message);
              });
            });
            tableBody.appendChild(tableRow);
          });
  
          // generate pagination links
          var paginationLinks = document.querySelector('#pagination');
          paginationLinks.innerHTML = '';
  
          if (currentPage > 1) {
            let previousPage = eval(currentPage) - eval(1);
            paginationLinks.innerHTML += '<a href="#" class="pagination-link" data-page="' + previousPage + '">&lt;</a>';
          }
  
          paginationLinks.innerHTML += '<a href="#" class="pagination-link active" data-page="' + currentPage + '">' + currentPage + '</a>';
          
          if (currentPage < response.totalPages) {
            let nextPage = eval(currentPage) + eval(1);
            paginationLinks.innerHTML += '<a href="#" class="pagination-link" data-page="' + nextPage + '">&gt;</a>';
          }
        })
        .catch(function(error) {
          console.log(error);
        });
    }
  
    const interval = setInterval(function() {
      // method to be executed;
      loadData(currentPage);
    }, 5000);
    
   //clearInterval(interval);
  });