const formPassword = document.querySelector("#forgot_password");

function validatePassword(password) {
    // Check for special characters
    const specialCharsRegex = /[!@#$%^&*(),.?":{}|<>]/;
    if (!specialCharsRegex.test(password)) {
      alert("Password must contain at least one special character.");
      return false;
    }
    
    // Check for at least one number
    const numberRegex = /\d/;
    if (!numberRegex.test(password)) {
      alert("Password must contain at least one number.");
      return false;
    }
    
    // Check for at least one uppercase letter
    const uppercaseRegex = /[A-Z]/;
    if (!uppercaseRegex.test(password)) {
      alert("Password must contain at least one uppercase letter.");
      return false;
    }
    
    // Check for at least one lowercase letter
    const lowercaseRegex = /[a-z]/;
    if (!lowercaseRegex.test(password)) {
      alert("Password must contain at least one lowercase letter.");
      return false;
    }
      
    
    // Check for minimum length of 8 characters
    if (password.length < 8) {
      alert("Password must be at least 8 characters long.");
      return false;
    }
    
    return true;
    }

function forgot_password(password, token){
  data = {
      token: token,
      password: password,
    }; 
fetch("//fizio-backend.local/users/passwordupdate", {
  method: "POST",
  body: JSON.stringify(data),
  headers: {
    "Content-Type": "application/json; charset=UTF-8",
  },
})
  .then((response) => response.json())
  .then((data) => {
    console.log(data);
    if (data.error) {
      alert("Your password or email address is incorrect, please enter your email address and try again.");
    } else if(data.data == 'success'){
        alert("Your password was updated successfully.")
        localStorage.clear();
        window.location.replace('/form.html');
    }
  })
  .catch((error) => {
    console.error("Error:", error.message);
  });  
}

  formPassword.addEventListener('submit', function(event) {
      event.preventDefault(); // prevent the form from submitting normally 
      if(document.querySelector("#password").value !== "" && document.querySelector("#password2").value !== "" && document.querySelector("#token").value !== ""){
        if(document.querySelector("#password2").value !== document.querySelector("#password").value){
            alert("Password and Password Confirm have to be Similar!")
        }else{
          if(validatePassword(document.querySelector("#password").value) == true ){
            forgot_password(document.querySelector("#password").value, document.querySelector("#token").value)            
          }     
        }
      }else{
        alert("Please fill in all required fields");
      } 
  }, true);
  
  