function register(){
    let data
    const email = localStorage.getItem("email");
    data = {
        name: document.querySelector("#name").value,
        email: email,
        phone_number: document.querySelector("#phone_number").value,
        gender: document.querySelector("#gender").value,
        county: document.querySelector("#county").value,
        town_or_city: document.querySelector("#town").value,
        password: document.querySelector("#password").value,
        schedules_id: localStorage.getItem('schedules_id'),
        payment: document.querySelector("#TransID").value               
    };

fetch("//fizio-backend.local/users/patients", {
    method: "POST",
    body: JSON.stringify(data),
    headers: {
    "Content-Type": "application/json; charset=UTF-8",
    },
})
    .then((response) => response.json())
    .then((data) => {
    //console.log(data);
        alert("Successfully added payment, kindly wait and check on your account for confirmation.");
        setTimeout(() => {
        window.location.replace('/');              
        localStorage.clear();
        }, 2000);  // Interval that occurs every 2seconds           
        document.querySelector("#name").value = '';
        document.querySelector("#email").value = '';
        document.querySelector("#phone_number").value = '';
        document.querySelector("#gender").value = '';
        document.querySelector("#county").value = '';
        document.querySelector("#town").value = ''; 
        document.querySelector("#TransID").value = ''; 
        document.querySelector("#password").value = '';
        document.querySelector("#password2").value = '';
    })
    .catch((error) => {
    console.error("Error:", error.message);
    });   
}

function payment() {
let data
data = {
    payment: document.querySelector("#TransID").value,               
};

fetch("//fizio-backend.local/users/checks/payment", {
    method: "POST",
    body: JSON.stringify(data),
    headers: {
    "Content-Type": "application/json; charset=UTF-8",
    },
})
    .then((response) => response.json())
    .then((data) => {
    //console.log(data);
    if(data.success == 1){
        //console.log(data.success)
        register();                
    }else if(data.success == 2){
        alert("Your MPESA Transaction ID has already been used")
    }
    })
    .catch((error) => {
    console.error("Error:", error.message);
});
}

function validatePassword(password) {
// Check for special characters
const specialCharsRegex = /[!@#$%^&*(),.?":{}|<>]/;
if (!specialCharsRegex.test(password)) {
  alert("Password must contain at least one special character.");
  return false;
}

// Check for at least one number
const numberRegex = /\d/;
if (!numberRegex.test(password)) {
  alert("Password must contain at least one number.");
  return false;
}

// Check for at least one uppercase letter
const uppercaseRegex = /[A-Z]/;
if (!uppercaseRegex.test(password)) {
  alert("Password must contain at least one uppercase letter.");
  return false;
}

// Check for at least one lowercase letter
const lowercaseRegex = /[a-z]/;
if (!lowercaseRegex.test(password)) {
  alert("Password must contain at least one lowercase letter.");
  return false;
}
  

// Check for minimum length of 8 characters
if (password.length < 8) {
  alert("Password must be at least 8 characters long.");
  return false;
}

return true;
}

function validatePhoneNumber(phone_number){
    const phonenumberRegex = /(0)[0-9]{9}/;
    if (!phonenumberRegex.test(phone_number)) {
      alert("Enter a correct Phone Number.");
      return false;
    }
    return true;   
}


const registration = localStorage.getItem('registration');
if(registration == null){
    window.location.replace('/selection.html');
}

const selectionFormA = document.querySelector(".selectionFormA");

selectionFormA.addEventListener('submit', function(event) {
event.preventDefault(); // prevent the form from submitting normally
if(document.querySelector("#name").value !== '' &&
document.querySelector("#phone_number").value !== '' &&
document.querySelector("#gender").value !== '' &&
document.querySelector("#county").value !== '' &&
document.querySelector("#town").value !== '' && 
document.querySelector("#TransID").value !== '' && 
document.querySelector("#password").value !== '' &&
document.querySelector("#password2").value !== '')
{
    if(document.querySelector("#password2").value !== document.querySelector("#password").value){
        alert("Password and Password Confirm have to be Similar!")
    }else{
        if(validatePhoneNumber(document.querySelector("#phone_number").value) == true){
            if(validatePassword(document.querySelector("#password").value) == true) {
                payment();//function payment is called
            } 
        }     
    }
}else {
    alert("Please fill in all the required fields");
}
}, true);