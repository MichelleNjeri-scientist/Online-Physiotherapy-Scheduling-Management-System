document.addEventListener("DOMContentLoaded", function() {
  //In order to allow a logged in user to quickly book for an appointment direclty from their dashboard
  //The user's email is set in localstorage as logged email, which is then accessed at set as the selection form email
  var logged_in_user_email = localStorage.getItem("logged_email")
  if(localStorage.getItem("logged_email") != null){
    document.querySelector("#email").value = logged_in_user_email;
    document.querySelector("#email").setAttribute('disabled', '');
  }
  localStorage.clear(); 
})


function submit_form(){
  let data
            data = {
                email: document.querySelector("#email").value
            };

          fetch("//fizio-backend.local/users/checks/patientemail", {
            method: "POST",
            body: JSON.stringify(data),
            headers: {
              "Content-Type": "application/json; charset=UTF-8",
            },
          })
            .then((response) => response.json())
            .then((data) => {
              console.log(data);
              if (data.error) {
                const errorMessage = document.querySelector(
                  ".error-message-all"
                );
                errorMessage.style.display = "block";
                errorMessage.innerText = data.error;
              } else {
                localStorage.setItem("email", document.querySelector("#email").value);
                if(data.success === 1){
                    localStorage.setItem("registration", 1);
                }else if(data.success === 2){
                    localStorage.setItem("registration", 2);
                }
                if(document.querySelector("#categories").value == 'general_consultation'){
                    window.location.replace('/calendar.html');
                }else if(document.querySelector("#categories").value == 'specific_consultation'){
                    window.location.replace('/selection-physios.html'); 
                }
              }
            })
            .catch((error) => {
              console.error("Error:", error.message);
            });
}

function validateEmail(emailID) {
  atpos = emailID.indexOf("@");
  dotpos = emailID.lastIndexOf(".");
  if (atpos < 1 || ( dotpos - atpos < 2 )) {
     return false;
  }
  return true;
}
  const selectionFormA = document.querySelector(".selectionFormA");

  selectionFormA.addEventListener('submit', function(event) {
        event.preventDefault(); // prevent the form from submitting normally
        if(document.querySelector("#categories").value !== '' && document.querySelector("#email").value !== ''){
          if(validateEmail(document.querySelector("#email").value) == true){
            submit_form();
          }else{
            alert('Please enter a valid email address');
          }
        }else{
          alert('Please enter all fields');
        }
    }, true);
    
    