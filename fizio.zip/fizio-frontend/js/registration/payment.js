function payment() {
    let data
    data = {
        payment: document.querySelector("#TransID").value,               
    };

    fetch("//fizio-backend.local/users/checks/payment", {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
        "Content-Type": "application/json; charset=UTF-8",
        },
    })
        .then((response) => response.json())
        .then((data) => {
        //console.log(data);
        if (data.error) {
            const errorMessage = document.querySelector(
            ".error-message-all"
            );
            errorMessage.style.display = "block";
            errorMessage.innerText = data.error;
        } else {      
            if(data.success == 1){
                //console.log(data.success)
                pay();                
            }else if(data.success == 2){
                alert("Your MPESA message has already been used");                 
            }                                   
        }
        })
        .catch((error) => {
        console.error("Error:", error.message);
    });
}
function pay() {
    let data;
    const schedules_id = localStorage.getItem("schedules_id");
    const email = localStorage.getItem("email");
    const payment = document.querySelector("#TransID").value;
    data = {
        schedules_id: schedules_id,  
        email: email,    
        payment: payment,         
    };

    fetch("//fizio-backend.local/users/checks/addpayment", {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
        "Content-Type": "application/json; charset=UTF-8",
        },
    })
        .then((response) => response.json())
        .then((data) => {
        //console.log(data);
        if (data.error) {
            const errorMessage = document.querySelector(
            ".error-message"
            );
            errorMessage.style.display = "block";
            errorMessage.innerText = data.error;
        } else {
            alert("Successfully added payment, kindly wait and check on your account for confirmation.");
            setTimeout(() => {
            localStorage.removeItem('registration');   
            localStorage.removeItem('email');   
            localStorage.removeItem('schedules_id');
            window.location.replace('/');              
            
            }, 2000);                                
        }
        })
        .catch((error) => {
        console.error("Error:", error.message);
    });
}

const selectionFormA = document.querySelector(".selectionFormA");

selectionFormA.addEventListener('submit', function(event) {
    event.preventDefault(); // prevent the form from submitting normally
    if(document.querySelector("#TransID").value !== ''){
        payment();
    }else{
        alert("Please fill in all the required fields");
    }
    
}, true);