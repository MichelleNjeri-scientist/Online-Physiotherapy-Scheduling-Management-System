        // get current date
        var today = new Date();

        // date today in YYYY-MM-DD format
        let date_today = today.getFullYear() + "-" + (today.getMonth() + 1).toString().padStart(2, "0") + "-" + today.getDate().toString().padStart(2, "0");
        // retrieve physio_id from Local Storage on the Browser
        const physio_id = localStorage.getItem('physio_id');
        fetch("//fizio-backend.local/consultations/schedules/views/calendar?date=" + date_today + "&physio_id=" + physio_id, {
            method: "GET",
            headers: {
            "Content-Type": "application/json; charset=UTF-8",
            },
        })
            .then((response) => response.json())
            .then((response) => {
                var events = response.data;
                displayEvents(events);                                       
            
            })
            .catch((error) => {
            console.error("Error:", error.message);
            });

        // get current month and year
        var month = today.getMonth();
        var year = today.getFullYear();

        // display calendar for current month and year
        displayCalendar(month, year);

        function displayCalendar(month, year) {
        // get number of days in the month
        var daysInMonth = new Date(year, month + 1, 0).getDate();
        //This line of code is used to determine the number of days in a specific month,
        // uses a 0 base indexing for months example jan = 0, day to 0, it actually refers to the last day of the previous month.
        // getDate() returns the day of the month (a number between 1 and 31) represented by the Date instance.

        // get first day of the month
        var firstDay = new Date(year, month, 1).getDay(); 
        //The 1 passed as the third argument represents the day of the month (the first day).
        // getDay() returns the day of the week (0-6) for the specified date.

        // create table element
        var table = document.createElement("table");

        // create header row
        var headerRow = document.createElement("tr");

        // create header cells and add them to the header row
        var daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
        for (var i = 0; i < daysOfWeek.length; i++) {
            var headerCell = document.createElement("th");
            headerCell.textContent = daysOfWeek[i];
            headerRow.appendChild(headerCell);
        }

        // add header row to table
        table.appendChild(headerRow);

        // create calendar rows
        var row = document.createElement("tr");
        var day = 1;
        for (var i = 0; i < 7; i++) {
            for (var j = 0; j < 7; j++) {
                if (i === 0 && j < firstDay) {
                    // add empty cells before the first day of the month
                    var cell = document.createElement("td");
                    row.appendChild(cell);
                } else if (day > daysInMonth) {
                    // add empty cells after the last day of the month
                    break;
                }else {
                    // add day cell
                    var cell = document.createElement("td");
                    cell.textContent = day;
                    cell.setAttribute("data-date", year + "-" + (month + 1).toString().padStart(2, "0") + "-" + day.toString().padStart(2, "0"));
                    cell.addEventListener("click", getEvents);
                    // check if date is before today and add CSS class to give it grey color
                    var cellDate = new Date(year, month, day);
                    if (cellDate < today) {
                        if (year === today.getFullYear() && month === today.getMonth() && day === today.getDate()) {
                            // highlight today's date
                            cell.classList.add("today");
                        }else{
                            cell.classList.add("beforeToday");
                        }
                    }
                    row.appendChild(cell);
                    day++;
                }
                
            }
            // add row to table
            table.appendChild(row);
            // create new row
            row = document.createElement("tr");
        }

        // add table to calendar div
        var calendar = document.getElementById("calendar");
        calendar.innerHTML = "";
        calendar.appendChild(table);

        // add month name to h3 element
        var monthName = document.createElement("h1");
        monthName.textContent = new Date(year, month).toLocaleString('en-us', { month: 'long' });
        calendar.insertBefore(monthName, table);        
        }

        function getEvents() {
            // get date from clicked cell
            var date = this.getAttribute("data-date");
            //this typically refers to the DOM element that triggered the event.
            //.getAttribute("data-date"): This is a method used on DOM elements to retrieve the value of a specific attribute.

            // retrieve physio_id from Local Storage on the Browser
            const physio_id = localStorage.getItem('physio_id');
            fetch("//fizio-backend.local/consultations/schedules/views/calendar?date=" + date + "&physio_id=" + physio_id, {
                method: "GET",
                headers: {
                  "Content-Type": "application/json; charset=UTF-8",
                },
              })
                .then((response) => response.json())
                .then((response) => {
                    var events = response.data;
                    displayEvents(events);                                       
                  
                })
                .catch((error) => {
                  console.error("Error:", error.message);
                });            
        }

        function bookEvent(schedules_id, time){
            localStorage.setItem("event_time", time);
            localStorage.setItem("schedules_id", schedules_id);
            const registration = localStorage.getItem("registration");

            if(registration == 1){
                window.location.replace('/payment.html');
            }else if(registration == 2){
                window.location.replace('/register.html');
            } 
        }        

        function displayEvents(events) {
            // create events list element
            var list = document.createElement("ul");
            // create list items for each event and add them to the list
            for (var i = 0; i < events.length; i++) {
                var event = events[i];// 'i' will represent the position of a schedule in the list(in the larger array)
                // create list item
                var item = document.createElement("li");
                // create time element
                var time = document.createElement("div");
                time.classList.add("time"); // <div class="time"></div>
                // create h2 element for date
                var date = document.createElement("h2");
                var day = new Date(event.date).getDate();// calls the date within a schedule and extract the day
                var month = new Date(event.date).toLocaleString('default', { month: 'short' });// calls the date within a schedule and extract the month
                date.innerHTML = day + '<br><span>' + month + '</span>';
                time.appendChild(date);
                item.appendChild(time);
                // create details element
                var details = document.createElement("div");
                details.classList.add("details");
                // create h3 element for time
                var timeText = document.createElement("h3");
                timeText.textContent = event.time;
                details.appendChild(timeText);
                // create a element for booking
                var bookingLink = document.createElement("button");
                //bookingLink.href = event.bookingLink;
                bookingLink.setAttribute("id", "time" + event.schedules_id)                
                bookingLink.textContent = "Book Slot";
                details.appendChild(bookingLink);
                // add item to list
                list.appendChild(item);
                item.appendChild(details);
                /*use a closure to create a new scope for each iteration of the loop. 
                This will ensure that each event listener has access to the correct event variable. 
                Here's how you can modify your code to use closures:*/
                (function(event) {
                    const el = item.querySelector("#time" + event.schedules_id);
                    el.addEventListener('click', function() {
                        bookEvent(event.schedules_id, event.time);
                    }); 
                })(event);                                                   
            }
            // add events list to events div
            var eventsDiv = document.getElementById("events");
            eventsDiv.innerHTML = "";
            eventsDiv.appendChild(list);            
        }
        
        
    // add navigation buttons for month-to-month pagination    
    //var nav = document.createElement("div");
    var nav = document.querySelector("#pagination");
    //nav.classList.add("pagination");
    // add "previous" button for navigating to previous month
    var prevButton = document.createElement("button");
    prevButton.textContent = "Previous Month";
    prevButton.addEventListener("click", function () {
        if (month === 0) {
        // if current month is January, switch to December of previous year
        month = 11;
        year--;
        } else {
        month--;
        }
        displayCalendar(month, year);
    });
    nav.appendChild(prevButton);

  // add "current month" button for returning to current month
    var currentButton = document.createElement("button");
    currentButton.textContent = "Current Month";
    currentButton.addEventListener("click", function () {       
        month = new Date().getMonth();
        year = new Date().getFullYear();
        displayCalendar(month, year);   
    }); 
    nav.appendChild(currentButton);
    
    //add "next month" button for going to next month
    var nextMonthBtn = document.createElement("button");
    nextMonthBtn.textContent = "Next Month";
    nextMonthBtn.addEventListener("click", function() {
    month++;
    if (month > 11) {
        month = 0;
        year++;
    }
    displayCalendar(month, year);
    });
    nav.appendChild(nextMonthBtn);    