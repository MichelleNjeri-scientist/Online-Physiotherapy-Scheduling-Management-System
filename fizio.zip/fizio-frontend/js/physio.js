class Physio {    
    constructor(){
        document.querySelector('body').style.display = 'none';
        const physio = localStorage.getItem('physio');
        this.validatePhysio(physio);
    }

    validatePhysio(physio) {
        if(physio != 1){
            //console.log(10);
            localStorage.clear();
            window.location.replace('/form.html');
        }else{
            //window.location.assign('dashboard.html');
            document.querySelector('body').style.display = 'block';
        }
    }
}