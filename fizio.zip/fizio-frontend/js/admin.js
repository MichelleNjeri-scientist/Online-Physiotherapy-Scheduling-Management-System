class Admin {    
    constructor(){
        document.querySelector('body').style.display = 'none';
        const admin = localStorage.getItem('admin');
        this.validateAdmin(admin);
    }

    validateAdmin(admin) {
        if(admin != 1){
            //console.log(10);
            localStorage.clear();
            window.location.replace('/form.html');
        }else{
            //window.location.assign('dashboard.html');
            document.querySelector('body').style.display = 'block';
        }
    }
}