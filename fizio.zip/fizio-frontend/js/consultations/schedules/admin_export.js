document.addEventListener("DOMContentLoaded", function() {

   //clearInterval(interval);
   const export_all = document.querySelector(".export-all");
  
   export_all.addEventListener('click', function(event) {
       event.preventDefault(); // prevent the form from submitting normally 
       if(document.getElementById("page_status").value != ''){
      var page_status = document.getElementById("page_status").value
      }else{
        var page_status = ''
      }
      if(document.getElementById("time_slot_start").value != ''){
        var time_slot_start = document.getElementById("time_slot_start").value
      }else{
        var time_slot_start = ''
      }       
       window.open("//fizio-backend.local/users/adminexportall?page_status="+ page_status +"&time_slot_start=" + time_slot_start, '_blank');       
   }, true);
   document.getElementById("filter-clear").addEventListener('click', function(e) {
      e.preventDefault();
      document.getElementById("page_status").value = ''
      document.getElementById("time_slot_start").value = ''
    });   
  });