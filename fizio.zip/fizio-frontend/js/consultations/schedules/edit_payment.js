document.addEventListener("DOMContentLoaded", function () {
    var payment = localStorage.getItem("payment");
    var payment_html = document.querySelector('#payment');
    payment_html.value = payment;     

      var modalBody = document.querySelector('.login-form');
      var submitBtn = modalBody.querySelector('input[type="submit"]');
      submitBtn.onclick = function(event) {
        event.preventDefault(); 
        submit_edit();
        
      }

      function submit_edit(){
        if(document.querySelector('#payment1').value !== ''){
            data = {
                payment: payment,
                payment1: document.querySelector('#payment1').value 
            };
        }else{
            data = {
                payment: payment,
            };        
        }          

          var form = document.querySelector('.login-form form');
          var formData = new FormData(form);
          console.log(formData.get('payment'));
          console.log(formData.get('payment1'));
      
          data = {
            schedules_id: JSON.parse(localStorage.getItem("schedules_id")),
            payment: formData.get('payment'),
            payment1: formData.get('payment1')
          };
      
          var url = '//fizio-backend.local/consultations/payments/confirm';
          fetch(url, {
            method: "POST",
            body: JSON.stringify(data),
            headers: {
              "Content-Type": "application/json; charset=UTF-8",
            },
          })
            .then(response => response.json())
            .then(function(response) {
              if(response.success){
                if(response.success == 1){
                    alert("Success! Payment has been accepted, Schedule has been edited!");
                }else{
                    alert("This payment has already been accepted before");
                }         
              }
              console.log(response.data)      
            })
            .catch(function(error) {
              console.log(error);
            });      
        }  
               
});