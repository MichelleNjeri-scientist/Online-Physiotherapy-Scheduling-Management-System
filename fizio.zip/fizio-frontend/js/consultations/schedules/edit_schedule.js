document.addEventListener("DOMContentLoaded", function () {
    var schedules_id = JSON.parse(localStorage.getItem("schedules_id"));
    var id = schedules_id;
    data = {
        schedules_id: id,
    };

    var url = '//fizio-backend.local/consultations/schedules/views/single';
    fetch(url, {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json; charset=UTF-8",
      },
    })
      .then(response => response.json())
      .then(function(response) {
        if(response.data){
          var time_slot_start_html = document.querySelector('#time_slot_start');
          time_slot_start_html.value = response.data.time_slot_start; 
          var time_slot_end_html = document.querySelector('#time_slot_end');
          time_slot_end_html.value = response.data.time_slot_end;           
        }     
      })
      .catch(function(error) {
        console.log(error);
      });

      var modalBody = document.querySelector('.login-form');
      var submitBtn = modalBody.querySelector('input[type="submit"]');
      submitBtn.onclick = function(event) {
        event.preventDefault(); 
        const timeSlotStart = new Date(document.getElementById("time_slot_start").value);
        const timeSlotEnd = new Date(document.getElementById("time_slot_end").value);

        if (document.getElementById("time_slot_start").value == '' || document.getElementById("time_slot_end").value == '') {
            alert("Please enter both time slot start and end values");
          } else {
            const now = new Date();
      
            if (timeSlotStart > timeSlotEnd) {
              alert("Time slot end must be greater than time slot start");
            } else if (timeSlotStart < now || timeSlotEnd < now) {
              alert("Time slots cannot be less than now or today");
            } else {
              // Validation passed, submit the form or perform further actions
              submit_edit(schedules_id);
            }            
          }
        
      }

      function submit_edit(schedules_id){
          
          var user = JSON.parse(localStorage.getItem("user"));
          var user_id = user['id'];

          var form = document.querySelector('.login-form form');
          var formData = new FormData(form);
          console.log(schedules_id);
          console.log(formData.get('time_slot_start'));
          console.log(formData.get('time_slot_end'));
      
          data = {
            physio_id: user_id,
            schedules_id: schedules_id,
            time_slot_start: formData.get('time_slot_start'),
            time_slot_end: formData.get('time_slot_end')
          };
      
          var overlay = document.querySelector('.overlay');
      
          var url = '//fizio-backend.local/consultations/schedules/edit';
          fetch(url, {
            method: "POST",
            body: JSON.stringify(data),
            headers: {
              "Content-Type": "application/json; charset=UTF-8",
            },
          })
            .then(response => response.json())
            .then(function(response) {
              if(response.data){
                if(response.data == 'success'){
                    document.getElementById("time_slot_start").value = '';
                    document.getElementById("time_slot_end").value = '';
                    alert("Success! Schedule has been edited!");
                }else{
                    alert(response);
                }         
              }
              console.log(response.data)      
            })
            .catch(function(error) {
              console.log(error);
            });      
        }  
               
});