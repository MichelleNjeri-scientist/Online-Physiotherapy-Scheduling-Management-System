fetch('//fizio-backend.local/consultations/schedules/views/physioslisted')
  .then(response => response.json())
  .then(response => {
    for(let i = 0; i < response.data.length; i++) {
      const card = document.createElement('div');
      card.classList.add('card');

      const span = document.createElement('span');
      card.appendChild(span);

      const imgBx = document.createElement('div');
      imgBx.classList.add('imgBx');
      const img = document.createElement('img');
      img.setAttribute('src', 'files/user.png');
      imgBx.appendChild(img);
      card.appendChild(imgBx);

      const contentLink = document.createElement('a');
      const registration = localStorage.getItem('registration');
      contentLink.setAttribute('href', 'calendar.html');
      const content = document.createElement('div');
      content.classList.add('content');
      content.setAttribute("id", response.data[i].id)

      const content1 = document.createElement('div');
      const h2 = document.createElement('h2');
      h2.innerText = response.data[i].name;
      const p = document.createElement('p');
      p.innerText = response.data[i].cv;

      content1.appendChild(h2);
      content1.appendChild(p);
      content.appendChild(content1);
      contentLink.appendChild(content);
      card.appendChild(contentLink);

      document.querySelector('#container').appendChild(card);

      document.querySelector('#'+ response.data[i].id).addEventListener('click', function() {
        localStorage.setItem("physio_id", response.data[i].physio_id);
      });      
    }
  })
  .catch(error => console.error(error));
