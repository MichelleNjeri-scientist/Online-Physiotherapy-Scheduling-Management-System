document.addEventListener("DOMContentLoaded", function() {
    
    // initialize page to 1
    var currentPage = 1;
  
    // load initial page of data
    loadData(currentPage);
  
    // listen for page change events
    document.addEventListener('click', function(e) {
      if (e.target && e.target.classList.contains('pagination-link')) {
        e.preventDefault();
        currentPage = e.target.dataset.page;
        loadData(currentPage);
      }
    });
    
  
    function loadData(page) {
      var user = JSON.parse(localStorage.getItem("user"));
      var user_id = user['id'];
  
      var url = '//fizio-backend.local/consultations/schedules/views/physio_export?physio_id=' + user_id;
      fetch(url)
        .then(response => response.json())
        .then(function(response) {
  
          // clear table body
          var tableBody = document.querySelector('#scheduleTable tbody');
          tableBody.innerHTML = '';
  
          // populate table body with data
          response.data.forEach(function(row) {
            var tableRow = document.createElement('tr');
            var myHTML = '';
  
            tableRow.innerHTML = '<td>' + row.name + '</td>' + '<td>' + row.email + '</td>'  + '<td>' + row.gender + '</td>'  + '<td>' + row.town_or_city + ' ' + row.county + '</td>' + '<td style="text-align:center"> <a href="#" class="btn open-patient"><ion-icon name="send-outline"></ion-icon></a></td>';
  
            tableRow.querySelector('.open-patient').addEventListener('click', function() {
              localStorage.setItem("logged_patient_id", row.patient_id) 
              localStorage.setItem("logged_patient_name", row.name) 
              window.location.replace('/physio-patient.html'); 
            });
            tableBody.appendChild(tableRow);
          });
  
          // generate pagination links
          var paginationLinks = document.querySelector('#pagination');
          paginationLinks.innerHTML = '';
  
          if (currentPage > 1) {
            let previousPage = eval(currentPage) - eval(1);
            paginationLinks.innerHTML += '<a href="#" class="pagination-link" data-page="' + previousPage + '">&lt;</a>';
          }
  
          paginationLinks.innerHTML += '<a href="#" class="pagination-link active" data-page="' + currentPage + '">' + currentPage + '</a>';
          
          if (currentPage < response.totalPages) {
            let nextPage = eval(currentPage) + eval(1);
            paginationLinks.innerHTML += '<a href="#" class="pagination-link" data-page="' + nextPage + '">&gt;</a>';
          }
        })
        .catch(function(error) {
          console.log(error);
        });
    }
  
    const interval = setInterval(function() {
      // method to be executed;
      loadData(currentPage);
    }, 5000);
    
   //clearInterval(interval);  
  });