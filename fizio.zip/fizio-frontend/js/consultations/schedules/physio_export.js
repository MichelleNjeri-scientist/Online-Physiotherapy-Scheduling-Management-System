document.addEventListener("DOMContentLoaded", function() {
    
  // initialize page to 1
  var currentPage = 1;

  // load initial page of data
  loadData(currentPage);

  // listen for page change events
  document.addEventListener('click', function(e) {
    if (e.target && e.target.classList.contains('pagination-link')) {
      e.preventDefault();
      currentPage = e.target.dataset.page;
      loadData(currentPage);
    }
  });
  

  function loadData(page) {
    var user = JSON.parse(localStorage.getItem("user"));
    var user_id = user['id'];

    var url = '//fizio-backend.local/consultations/schedules/views/physio_export?physio_id=' + user_id;
    fetch(url)
      .then(response => response.json())
      .then(function(response) {

        // clear table body
        var tableBody = document.querySelector('#scheduleTable tbody');
        tableBody.innerHTML = '';

        // populate table body with data
        response.data.forEach(function(row) {
          var tableRow = document.createElement('tr');
          var myHTML = '';

          tableRow.innerHTML = '<td>' + row.name + '</td>' + '<td>' + row.email + '</td>'  + '<td>' + row.gender + '</td>'  + '<td>' + row.town_or_city + ' ' + row.county + '</td>' + '<td style="text-align:center"> <a href="#" class="btn export"><ion-icon name="download-outline"></ion-icon></a></td>';

          tableRow.querySelector('.export').addEventListener('click', function() {
              window.open("//fizio-backend.local/users/patientexport?patient_id="+ row.patient_id, '_blank');  
          });
          tableBody.appendChild(tableRow);
        });

        // generate pagination links
        var paginationLinks = document.querySelector('#pagination');
        paginationLinks.innerHTML = '';

        if (currentPage > 1) {
          let previousPage = eval(currentPage) - eval(1);
          paginationLinks.innerHTML += '<a href="#" class="pagination-link" data-page="' + previousPage + '">&lt;</a>';
        }

        paginationLinks.innerHTML += '<a href="#" class="pagination-link active" data-page="' + currentPage + '">' + currentPage + '</a>';
        
        if (currentPage < response.totalPages) {
          let nextPage = eval(currentPage) + eval(1);
          paginationLinks.innerHTML += '<a href="#" class="pagination-link" data-page="' + nextPage + '">&gt;</a>';
        }
      })
      .catch(function(error) {
        console.log(error);
      });
  }

  const interval = setInterval(function() {
    // method to be executed;
    loadData(currentPage);
  }, 5000);
  
 //clearInterval(interval);
 const export_all = document.querySelector(".export-all");

 export_all.addEventListener('click', function(event) {
     event.preventDefault(); // prevent the form from submitting normally 
     var user = JSON.parse(localStorage.getItem("user"));
     var user_id = user['id'];
     if(document.getElementById("page_status").value != ''){
    var page_status = document.getElementById("page_status").value
    }else{
      var page_status = ''
    }
    if(document.getElementById("time_slot_start").value != ''){
      var time_slot_start = document.getElementById("time_slot_start").value
    }else{
      var time_slot_start = ''
    }       
     window.open("//fizio-backend.local/users/patientexportall?physio_id="+ user_id + "&page_status="+ page_status +"&time_slot_start=" + time_slot_start, '_blank');       
 }, true);
 document.getElementById("filter-clear").addEventListener('click', function(e) {
    e.preventDefault();
    document.getElementById("page_status").value = ''
    document.getElementById("time_slot_start").value = ''
  });   
});