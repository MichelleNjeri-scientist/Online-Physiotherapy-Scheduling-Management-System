document.addEventListener("DOMContentLoaded", function() {
    
    // initialize page to 1
    var currentPage = 1;
  
    // load initial page of data
    loadData(currentPage);
  
    // listen for page change events
    document.addEventListener('click', function(e) {
      if (e.target && e.target.classList.contains('pagination-link')) {
        e.preventDefault();
        currentPage = e.target.dataset.page;
        loadData(currentPage);
      }
    });
    
    document.getElementById("filter-submit").addEventListener('click', function(e) {
      e.preventDefault();
      loadData(currentPage);
    });
  
    document.getElementById("filter-clear").addEventListener('click', function(e) {
      e.preventDefault();
      document.getElementById("page_status").value = ''
      document.getElementById("time_slot_start").value = ''
    });
  
    function loadData(page) {
      var user = JSON.parse(localStorage.getItem("user"));
      var user_id = user['id'];
      if(document.getElementById("page_status").value != ''){
        var page_status = document.getElementById("page_status").value
      }else{
        var page_status = ''
      }
      if(document.getElementById("time_slot_start").value != ''){
        var time_slot_start = document.getElementById("time_slot_start").value
      }else{
        var time_slot_start = ''
      }
  
      var url = '//fizio-backend.local/consultations/schedules/views/admin?page=' + page + '&page_status=' + page_status + '&time_slot_start=' + time_slot_start;
      fetch(url)
        .then(response => response.json())
        .then(function(response) {
  
          // clear table body
          var tableBody = document.querySelector('#scheduleTable tbody');
          tableBody.innerHTML = '';
  
          // populate table body with data
          response.data.forEach(function(row) {
            var tableRow = document.createElement('tr');
            var myHTML = '';
  
            tableRow.innerHTML = '<td>' + row.status + '</td>' + '<td>' + row.time_slot_start + '</td>' + '<td>' + row.time_slot_end + '</td>' + '<td style="text-align:center"> <a href="#" class="btn edit-recommendations"><ion-icon name="create-outline"></ion-icon></a></td>' + '<td style="white-space: nowrap;"><span class="status '+ row.active_status_class +'">' + row.active_status + '</span></td>' + '<td>' + row.payment + '</td>' + '<td style="text-align:center"> <a href="#" class="btn payment-button"><ion-icon name="create-outline"></ion-icon></a></td>';
            tableRow.querySelector('.payment-button').addEventListener('click', function() {
              
              if(row.active_status == 'payment yet to be cleared'){
                localStorage.removeItem("payment");
                localStorage.removeItem("schedules_id");
                localStorage.setItem("payment", row.payment);
                localStorage.setItem("schedules_id", row.schedules_id);
                window.location.replace('/edit-payment.html');               
              }else{
                alert("This schedule cannot be changed");
              }
            });
  
            tableRow.querySelector('.edit-recommendations').addEventListener('click', function() {
              localStorage.removeItem("schedules_id");
              localStorage.setItem("schedules_id", row.schedules_id);
              window.location.replace('/view-recommendations-admin.html');
            });
            tableBody.appendChild(tableRow);
          });
  
          // generate pagination links
          var paginationLinks = document.querySelector('#pagination');
          paginationLinks.innerHTML = '';
  
          if (currentPage > 1) {
            let previousPage = eval(currentPage) - eval(1);
            paginationLinks.innerHTML += '<a href="#" class="pagination-link" data-page="' + previousPage + '">&lt;</a>';
          }
  
          paginationLinks.innerHTML += '<a href="#" class="pagination-link active" data-page="' + currentPage + '">' + currentPage + '</a>';
          
          if (currentPage < response.totalPages) {
            let nextPage = eval(currentPage) + eval(1);
            paginationLinks.innerHTML += '<a href="#" class="pagination-link" data-page="' + nextPage + '">&gt;</a>';
          }
        })
        .catch(function(error) {
          console.log(error);
        });
    }
  
    const interval = setInterval(function() {
      // method to be executed;
      loadData(currentPage);
    }, 5000);
    document.querySelector('.change-password').onclick = function (event) {
      //event.preventDefault(); 
      var user = JSON.parse(localStorage.getItem("user"));
      var email = user["email"];
      let data = {
        email: email,
        user_type: 3,
      }; 
    fetch("//fizio-backend.local/users/forgotpassword", {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json; charset=UTF-8",
      },
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        if (data.error) {
          alert("Your password or email address is incorrect, please enter your email address and try again.");
        } else {
          alert("Use this token to change your password: " + data);
          window.location.replace('/change-password.html');
        }
      })
      .catch((error) => {
        console.error("Error:", error.message);
      });
      }
   //clearInterval(interval);
  });