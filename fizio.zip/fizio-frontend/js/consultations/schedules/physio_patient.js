document.addEventListener("DOMContentLoaded", function() {

    
    // initialize page to 1
    var currentPage = 1;
    
    // load initial page of data
    loadData(currentPage);
    
    // listen for page change events
    document.addEventListener('click', function(e) {
      if (e.target && e.target.classList.contains('pagination-link')) {
        e.preventDefault();
        currentPage = e.target.dataset.page;
        loadData(currentPage);
      }
    });
    
    
    function loadData(page) {
      var user_id = localStorage.getItem("logged_patient_id");
      document.querySelector(".patient-name").innerHTML = localStorage.getItem("logged_patient_name");
    
      var url = '//fizio-backend.local/consultations/schedules/views/patient?page=' + page + '&patient_id=' + user_id;
      fetch(url)
        .then(response => response.json())
        .then(function(response) {
          // clear table body
          var tableBody = document.querySelector('#scheduleTable tbody');
          tableBody.innerHTML = '';
    
          // populate table body with data
          response.data.forEach(function(row) {
            var tableRow = document.createElement('tr');
    
            tableRow.innerHTML = '<td>' + row.status + '</td>' + '<td>' + row.time_slot_start + '</td>' + '<td>' + row.time_slot_end + '</td>' + '<td style="text-align:center"> <a href="#" class="btn edit-recommendations"><ion-icon name="create-outline"></ion-icon></a></td>' + '<td style="white-space: nowrap;"><span class="status '+ row.active_status_class +'">' + row.active_status + '</span></td>';
    
            tableRow.querySelector('.edit-recommendations').addEventListener('click', function() {
              localStorage.removeItem("schedules_id");
              localStorage.setItem("schedules_id", row.schedules_id);
              window.location.replace('/view-recommendations-physio.html');
            });
            tableBody.appendChild(tableRow);
          });
    
          // generate pagination links
          var paginationLinks = document.querySelector('#pagination');
          paginationLinks.innerHTML = '';
    
          if (currentPage > 1) {
            let previousPage = eval(currentPage) - eval(1);
            paginationLinks.innerHTML += '<a href="#" class="pagination-link" data-page="' + previousPage + '">&lt;</a>';
          }
    
          paginationLinks.innerHTML += '<a href="#" class="pagination-link active" data-page="' + currentPage + '">' + currentPage + '</a>';
          
          if (currentPage < response.totalPages) {
            let nextPage = eval(currentPage) + eval(1);
            paginationLinks.innerHTML += '<a href="#" class="pagination-link" data-page="' + nextPage + '">&gt;</a>';
          }
        })
        .catch(function(error) {
          console.log(error);
        });
    }
    
    const interval = setInterval(function() {
      // method to be executed;
      loadData(currentPage);
    }, 5000);
    
    //clearInterval(interval);
    });