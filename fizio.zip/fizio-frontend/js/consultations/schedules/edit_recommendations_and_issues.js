document.addEventListener("DOMContentLoaded", function () {
  var schedules_id = JSON.parse(localStorage.getItem("schedules_id"));
  view();

  function view(){
      data = {
          schedules_id: schedules_id,
      };    
      
      var url = '//fizio-backend.local/consultations/patient-issues/single';
      fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json; charset=UTF-8",
        },
      })
        .then(response => response.json())
        .then(function(response) {
          if(response.data){
            var issue_html = document.getElementById('issue');
            issue_html.value = response.data.issue;          
          }
        })
        .catch(function(error) {
          console.log(error);
        });   
        
        var url = '//fizio-backend.local/consultations/recommendations/single';
        fetch(url, {
          method: "POST",
          body: JSON.stringify(data),
          headers: {
            "Content-Type": "application/json; charset=UTF-8",
          },
        })
          .then(response => response.json())
          .then(function(response) {
            if(response.data){
              var recommendation_html = document.querySelector('#recommendation');
              recommendation_html.value = response.data.recommendation; 
              var prescription_html = document.querySelector('#prescription');
              prescription_html.value = response.data.prescription;          
            }     
          })
          .catch(function(error) {
            console.log(error);
          });        
  } 
  var bookBtn = document.querySelector('.book-button');

  bookBtn.onclick = function (event) {
      //event.preventDefault(); 
      var user = JSON.parse(localStorage.getItem("user"));
      var email = user["email"];
      //localStorage.setItem("logged_email", email) 
      window.location.replace('/selection.html');
  }
  var modalBody = document.querySelector('.login-form');
    var submitBtn = modalBody.querySelector('input[type="submit"]');
    submitBtn.onclick = function(event) {
      event.preventDefault(); 
      if (
          document.getElementById("issue").value == '' || 
          document.getElementById("recommendation").value == '' ||
          document.getElementById("prescription").value == ''
      ) {
          alert("fill in all fields before submitting")
      }
      else{
          submit_issue(); 
          submit_recommendation();                    
      }        
  }
  function submit_issue(){
      var form = document.querySelector('.login-form form');
      var formData = new FormData(form);
      console.log(schedules_id);
      console.log(formData.get('issue'));
  
      data = {
        schedules_id: schedules_id,
        issue: formData.get('issue'),
      };
  
      var overlay = document.querySelector('.overlay');
  
      var url = '//fizio-backend.local/consultations/patient-issues/edit';
      fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json; charset=UTF-8",
        },
      })
        .then(response => response.json())
        .then(function(response) {
          if(response.data){
            if(response.data == 'success'){
              alert("Successfully submitted!")
            }else{
              alert(response.message);
            }         
          }
          console.log(response.data)     
        })
        .catch(function(error) {
          console.log(error);
        });    
    }
    function submit_recommendation(){
      var form = document.querySelector('.login-form form');
      var formData = new FormData(form);
      console.log(schedules_id);
      console.log(formData.get('recommendation'));
      console.log(formData.get('prescription'));
  
      data = {
        schedules_id: schedules_id,
        recommendation: formData.get('recommendation'),
        prescription: formData.get('prescription'),
      };
  
      var overlay = document.querySelector('.overlay');
  
      var url = '//fizio-backend.local/consultations/recommendations/edit';
      fetch(url, {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json; charset=UTF-8",
        },
      })
        .then(response => response.json())
        .then(function(response) {
          overlay.style.display = 'none';
          if(response.data){
              if(response.data == 'success'){
                  alert("Successfully submitted!");
                }else{
                  alert(response.message);
                }          
          }
          console.log(response.data)     
        })
        .catch(function(error) {
          console.log(error);
          overlay.style.display = 'none';
        });    
    }       
});