document.addEventListener("DOMContentLoaded", function () {
    var schedules_id = JSON.parse(localStorage.getItem("schedules_id"));
    view();

    function view(){
        data = {
            schedules_id: schedules_id,
        };    
        
        var url = '//fizio-backend.local/consultations/patient-issues/single';
        fetch(url, {
          method: "POST",
          body: JSON.stringify(data),
          headers: {
            "Content-Type": "application/json; charset=UTF-8",
          },
        })
          .then(response => response.json())
          .then(function(response) {
            if(response.data){
              var issue_html = document.getElementById('issue');
              issue_html.value = response.data.issue;          
            }
          })
          .catch(function(error) {
            console.log(error);
          });   
          
          var url = '//fizio-backend.local/consultations/recommendations/single';
          fetch(url, {
            method: "POST",
            body: JSON.stringify(data),
            headers: {
              "Content-Type": "application/json; charset=UTF-8",
            },
          })
            .then(response => response.json())
            .then(function(response) {
              if(response.data){
                var recommendation_html = document.querySelector('#recommendation');
                recommendation_html.value = response.data.recommendation; 
                var prescription_html = document.querySelector('#prescription');
                prescription_html.value = response.data.prescription;          
              }     
            })
            .catch(function(error) {
              console.log(error);
            });        
    }       
});