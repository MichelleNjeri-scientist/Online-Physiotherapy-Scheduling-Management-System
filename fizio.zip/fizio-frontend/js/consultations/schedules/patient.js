document.addEventListener("DOMContentLoaded", function() {

    
    // initialize page to 1
    var currentPage = 1;
  
    // load initial page of data
    loadData(currentPage);
  
    // listen for page change events
    document.addEventListener('click', function(e) {
      if (e.target && e.target.classList.contains('pagination-link')) {
        e.preventDefault();
        currentPage = e.target.dataset.page;
        loadData(currentPage);
      }
    });
    
  
    function loadData(page) {
      var user = JSON.parse(localStorage.getItem("user"));
      var user_id = user['id'];
  
      var url = '//fizio-backend.local/consultations/schedules/views/patient?page=' + page + '&patient_id=' + user_id;
      fetch(url)
        .then(response => response.json())
        .then(function(response) {
          // clear table body
          var tableBody = document.querySelector('#scheduleTable tbody');
          tableBody.innerHTML = '';
  
          // populate table body with data
          response.data.forEach(function(row) {
            var tableRow = document.createElement('tr');
  
            tableRow.innerHTML = '<td>' + row.status + '</td>' + '<td>' + row.time_slot_start + '</td>' + '<td>' + row.time_slot_end + '</td>' + '<td style="text-align:center"> <a href="#" class="btn edit-recommendations"><ion-icon name="create-outline"></ion-icon></a></td>' + '<td style="white-space: nowrap;"><span class="status '+ row.active_status_class +'">' + row.active_status + '</span></td>';
  
            tableRow.querySelector('.edit-recommendations').addEventListener('click', function() {
              localStorage.removeItem("schedules_id");
              localStorage.setItem("schedules_id", row.schedules_id);
              window.location.replace('/view_recommendations_and_issues.html');
            });
            tableBody.appendChild(tableRow);
          });
  
          // generate pagination links
          var paginationLinks = document.querySelector('#pagination');
          paginationLinks.innerHTML = '';
  
          if (currentPage > 1) {
            let previousPage = eval(currentPage) - eval(1);
            paginationLinks.innerHTML += '<a href="#" class="pagination-link" data-page="' + previousPage + '">&lt;</a>';
          }
  
          paginationLinks.innerHTML += '<a href="#" class="pagination-link active" data-page="' + currentPage + '">' + currentPage + '</a>';
          
          if (currentPage < response.totalPages) {
            let nextPage = eval(currentPage) + eval(1);
            paginationLinks.innerHTML += '<a href="#" class="pagination-link" data-page="' + nextPage + '">&gt;</a>';
          }
        })
        .catch(function(error) {
          console.log(error);
        });
    }
  
    const interval = setInterval(function() {
      // method to be executed;
      loadData(currentPage);
    }, 5000);
    
   //clearInterval(interval);
  });
  var bookBtn = document.querySelector('.book-button');

  bookBtn.onclick = function (event) {
    //event.preventDefault(); 
    var user = JSON.parse(localStorage.getItem("user"));
    var email = user["email"];
    localStorage.setItem("logged_email", email) 
    window.location.replace('/selection.html');
  }

  document.querySelector('.change-password').onclick = function (event) {
    //event.preventDefault(); 
    var user = JSON.parse(localStorage.getItem("user"));
    var email = user["email"];
    let data = {
      email: email,
      user_type: 2,
    }; 
  fetch("//fizio-backend.local/users/forgotpassword", {
    method: "POST",
    body: JSON.stringify(data),
    headers: {
      "Content-Type": "application/json; charset=UTF-8",
    },
  })
    .then((response) => response.json())
    .then((data) => {
      console.log(data);
      if (data.error) {
        alert("Your password or email address is incorrect, please enter your email address and try again.");
      } else {
        alert("Use this token to change your password: " + data);
        window.location.replace('/change-password.html');
      }
    })
    .catch((error) => {
      console.error("Error:", error.message);
    });
    }