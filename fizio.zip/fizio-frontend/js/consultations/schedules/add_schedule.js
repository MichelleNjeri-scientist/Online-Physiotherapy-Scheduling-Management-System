document.addEventListener("DOMContentLoaded", function () {
  var modalBody = document.querySelector(".login-form");
  var submitBtn = modalBody.querySelector('input[type="submit"]');

  submitBtn.onclick = function (event) {
    event.preventDefault(); 
    const timeSlotStart = new Date(document.getElementById("time_slot_start").value);
    const timeSlotEnd = new Date(document.getElementById("time_slot_end").value);

    if (document.getElementById("time_slot_start").value == '' || document.getElementById("time_slot_end").value == '') {
        alert("Please enter both time slot start and end values");
      } else {
        const now = new Date();
  
        if (timeSlotStart > timeSlotEnd) {
          alert("Time slot end must be greater than time slot start");
        } else if (timeSlotStart < now || timeSlotEnd < now) {
          alert("Time slots cannot be less than now or today");
        } else {
          // Validation passed, submit the form or perform further actions
          submit_add();
        }            
      }   
  };
  function submit_add(){
    var user = JSON.parse(localStorage.getItem("user"));
    var user_id = user["id"];
    var schedules_id = "none";
    var form = document.querySelector(".login-form form");
    var formData = new FormData(form);
    console.log(schedules_id);
    console.log(formData.get("time_slot_start"));
    console.log(formData.get("time_slot_end"));

    data = {
      physio_id: user_id,
      schedules_id: schedules_id,
      time_slot_start: formData.get("time_slot_start"),
      time_slot_end: formData.get("time_slot_end"),
    };

    var url = "//fizio-backend.local/consultations/schedules/edit";
    fetch(url, {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json; charset=UTF-8",
      },
    })
      .then((response) => response.json())
      .then(function (response) {
        if (response.data) {
          if (response.data == "success") {
            document.getElementById("time_slot_start").value = '';
            document.getElementById("time_slot_end").value = '';
            alert("Success! Schedule has been added!");
          }else{
            alert(response.message);
          } 
        } else {
          alert(response.message);
        }

        console.log(response);
      })
      .catch(function (error) {
        console.log(error);
      });    
  }
});
