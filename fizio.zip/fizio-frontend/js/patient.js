class Patient {    
    constructor(){
        document.querySelector('body').style.display = 'none';
        const patient = localStorage.getItem('patient');
        this.validatePatient(patient);
    }

    validatePatient(patient) {
        if(patient != 1){
         //   console.log(20);
            localStorage.clear();
            window.location.replace('/form.html');
        }else{
            //window.location.assign('dashboard.html');
            document.querySelector('body').style.display = 'block';
        }
    }
}