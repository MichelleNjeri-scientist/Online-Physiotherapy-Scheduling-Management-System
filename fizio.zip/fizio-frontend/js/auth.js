class Auth {    
    constructor(){
        document.querySelector('body').style.display = 'none';
        const auth = localStorage.getItem('auth');
        this.validateAuth(auth);
    }
    /*
    This line defines the constructor method of the Auth class. 
    The constructor is a special method that is automatically called when an object is created from the class. 
    It initializes the object's properties and executes any code required for setup.
    */

    validateAuth(auth) {
        if(auth != 1){
            window.location.replace('/form.html');
        }else{
            //window.location.assign('dashboard.html');
            document.querySelector('body').style.display = 'block';
        }
    }

    signOut(){
        localStorage.clear();
        window.location.replace('/'); 
    }
}