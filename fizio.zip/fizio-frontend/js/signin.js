function signin(userType){
  if(userType == 1){
    data = {
        email: document.querySelector("#physio-email").value,
        password: document.querySelector("#physio-password").value,
        user_type: userType,
      };
  }else if(userType == 2){
    data = {
        email: document.querySelector("#patient-email").value,
        password: document.querySelector("#patient-password").value,
        user_type: userType,
      };
  }else if(userType == 3){
    data = {
        email: document.querySelector("#admin-email").value,
        password: document.querySelector("#admin-password").value,
        user_type: userType,
      };
  }  
  fetch("//fizio-backend.local/users/auth", {
    method: "POST",
    body: JSON.stringify(data),
    headers: {
      "Content-Type": "application/json; charset=UTF-8",
    },
  })
    .then((response) => response.json())
    .then((data) => {
      console.log(data);
      if (data.error) {
        alert("Your password or email address is incorrect, please enter your email address and try again.");
      } else {
        localStorage.setItem("auth", 1);
        localStorage.setItem("user", JSON.stringify(data));
        if(userType == 1){
            localStorage.setItem("physio", 1);
            window.location.replace('/physio-dashboard.html');                    
        }else if (userType == 2){
            localStorage.setItem("patient", 1);
            window.location.replace('/dashboard.html');
        }else if (userType == 3){
          localStorage.setItem("admin", 1);
          window.location.replace('/admin-dashboard.html');
      }
      }
    })
    .catch((error) => {
      console.error("Error:", error.message);
    });  
}
function validateEmail(emailID) {
  atpos = emailID.indexOf("@");
  dotpos = emailID.lastIndexOf(".");
  if (atpos < 1 || ( dotpos - atpos < 2 )) {
     return false;
  }
  return true;
}

  const formPhysio = document.querySelector("#physio-type");
  const formPatient = document.querySelector("#patient-type");
  const formAdmin = document.querySelector("#admin-type");

  document.querySelector("#user_type_button").addEventListener('click', function(event) {
    event.preventDefault(); // prevent the form from submitting normally 
    if(document.querySelector("#user_type").value !== ""){
      document.querySelector("#physio-type").classList.remove("viewForm");
      document.querySelector("#patient-type").classList.remove("viewForm");
      document.querySelector("#admin-type").classList.remove("viewForm");
      document.querySelector("#physio-type").classList.add("hideSelect");
      document.querySelector("#patient-type").classList.add("hideSelect");
      document.querySelector("#admin-type").classList.add("hideSelect");
      document.querySelector("#userTypeForm").classList.remove("hideSelect");

      document.querySelector(".btn-a").classList.add("viewForm");
      document.querySelector(".btn-a").classList.remove("hideSelect");

      if(document.querySelector("#user_type").value == "1"){
        document.querySelector("#physio-type").classList.add("viewForm");
        document.querySelector("#physio-type").classList.remove("hideSelect");
        document.querySelector("#userTypeForm").classList.add("hideSelect");
      }else if(document.querySelector("#user_type").value == "2"){
        document.querySelector("#patient-type").classList.add("viewForm");  
        document.querySelector("#patient-type").classList.remove("hideSelect"); 
        document.querySelector("#userTypeForm").classList.add("hideSelect");   
      }else if(document.querySelector("#user_type").value == "3"){
        document.querySelector("#admin-type").classList.add("viewForm"); 
        document.querySelector("#admin-type").classList.remove("hideSelect");
        document.querySelector("#userTypeForm").classList.add("hideSelect");    
      }      
    }else{
      alert("Please fill in all required fields");
    } 
  }, true);
  
  document.querySelector(".btn-a").addEventListener('click', function(event) {
    event.preventDefault(); // prevent the form from submitting normally 
    console.log(document.querySelector("#user_type").value)
    if(document.querySelector("#user_type").value !== ""){
      if(document.querySelector("#user_type").value == "1"){
        if(document.querySelector("#physio-email").value !== ""){
          if(validateEmail(document.querySelector("#physio-email").value) === true){
            forgot_password(document.querySelector("#user_type_1").value, document.querySelector("#physio-email").value);
          }else{
            alert('Please enter a valid email address');
          }
        }else{
          alert("Please fill in the email address");
        } 
      }else if(document.querySelector("#user_type").value == "2"){
        if(document.querySelector("#patient-email").value !== ""){
          if(validateEmail(document.querySelector("#patient-email").value) === true){
            forgot_password(document.querySelector("#user_type_2").value, document.querySelector("#patient-email").value);
          }else{
            alert('Please enter a valid email address');
          }
        }else{
          alert("Please fill in the email address");
        }    
      }else if(document.querySelector("#user_type").value == "3"){
        if(document.querySelector("#admin-email").value !== ""){
          if(validateEmail(document.querySelector("#admin-email").value) === true){
            forgot_password(document.querySelector("#user_type_3").value, document.querySelector("#admin-email").value);
          }else{
            alert('Please enter a valid email address');
          }
        }else{
          alert("Please fill in the email address");
        }    
      }      
    }else{
      alert("Please fill in the email address");
    } 
  }, true);  

  function forgot_password(userType, email){
    let data = {
        email: email,
        user_type: userType,
      }; 
  fetch("//fizio-backend.local/users/forgotpassword", {
    method: "POST",
    body: JSON.stringify(data),
    headers: {
      "Content-Type": "application/json; charset=UTF-8",
    },
  })
    .then((response) => response.json())
    .then((data) => {
      console.log(data);
      if (data.error) {
        alert("Your password or email address is incorrect, please enter your email address and try again.");
      } else {
        alert("Use this token to change your password: " + data);
        window.location.replace('/forgot-password.html');
      }
    })
    .catch((error) => {
      console.error("Error:", error.message);
    });  
  }

    formPhysio.addEventListener('submit', function(event) {
        event.preventDefault(); // prevent the form from submitting normally 
        if(document.querySelector("#physio-email").value !== "" && document.querySelector("#physio-password").value !== ""){
          let userType = document.querySelector("#user_type_1").value;
          if(validateEmail(document.querySelector("#physio-email").value) === true){
            signin(userType);
          }else{
            alert('Please enter a valid email address');
          }
        }else{
          alert("Please fill in all required fields");
        } 
    }, true);

    formPatient.addEventListener('submit', function(event) {
        event.preventDefault(); // prevent the form from submitting normally 
        if(document.querySelector("#patient-email").value !== "" && document.querySelector("#patient-password").value !== ""){
          let userType = document.querySelector("#user_type_2").value;
          if(validateEmail(document.querySelector("#patient-email").value) === true){
            signin(userType);
          }else{
            alert('Please enter a valid email address');
          }
        }else{
          alert("Please fill in all required fields");
        } 
    }, true);

  formAdmin.addEventListener('submit', function(event) {
      event.preventDefault(); // prevent the form from submitting normally 
      if(document.querySelector("#admin-email").value !== "" && document.querySelector("#admin-password").value !== ""){
        let userType = document.querySelector("#user_type_3").value;
        if(validateEmail(document.querySelector("#admin-email").value) === true){
          signin(userType);
        }else{
          alert('Please enter a valid email address');
        }
      }else{
        alert("Please fill in all required fields");
      } 
  }, true);
    
    