const auth = new Auth();
const patient = new Patient();

document.querySelector('.signOut').addEventListener('click', (e) =>{
    auth.signOut();
})

var presConfig = {
    autoLogoutTimer: null
}
startAutoLogoutTimer(); // starts the initial timer

window.addEventListener("click", startAutoLogoutTimer);// listens for clicking on the page and resets to a new 60 seconds

function startAutoLogoutTimer() {
    var sessionTime = 30 * 1000; //60 seconds
    clearTimeout(presConfig.autoLogoutTimer);
    presConfig.autoLogoutTimer = setTimeout(function() {
        alert("You are being logged out due to inactivity")
        auth.signOut();
    }, sessionTime);
}
/*
The given code sets up an auto-logout feature for a user after 60 seconds of inactivity. 
It initializes the presConfig object with a null value for the autoLogoutTimer property. 
The startAutoLogoutTimer() function is called initially and also triggered whenever
the user clicks anywhere within the window. Inside the function, 
a timeout is set for 60 seconds, and any previously set timeout is cleared.
After the specified duration, an alert message is displayed to inform the user about 
the logout due to inactivity, and the auth.signOut() function is called to log the user out. 
This ensures that the user is automatically logged out if no activity is detected within 
the specified timeframe.
*/