const auth = new Auth();
const physio = new Physio();

document.querySelector('.signOut').addEventListener('click', (e) =>{
    auth.signOut();
})

/* 
the code creates instances of the Auth and Physio classes using the new keyword (const auth, const physio). 
It then adds a click event listener to an element with the class signOut, and when the element is clicked, 
it calls the signOut method of the Auth instance (auth). This code handles user sign-out functionality, 
triggering the necessary actions when the sign-out button or element is clicked
*/

var presConfig = {
    autoLogoutTimer: null
}
startAutoLogoutTimer();

window.addEventListener("click", startAutoLogoutTimer);

function startAutoLogoutTimer() {
    var sessionTime = 60 * 1000; //60 seconds
    clearTimeout(presConfig.autoLogoutTimer);
    presConfig.autoLogoutTimer = setTimeout(function() {
        alert("You are being logged out due to inactivity")
        auth.signOut();
    }, sessionTime);
}
/*
The given code sets up an auto-logout feature for a user after 60 seconds of inactivity. 
It initializes the presConfig object with a null value for the autoLogoutTimer property. 
The startAutoLogoutTimer() function is called initially and also triggered whenever
the user clicks anywhere within the window. Inside the function, 
a timeout is set for 60 seconds, and any previously set timeout is cleared.
After the specified duration, an alert message is displayed to inform the user about 
the logout due to inactivity, and the auth.signOut() function is called to log the user out. 
This ensures that the user is automatically logged out if no activity is detected within 
the specified timeframe.
*/