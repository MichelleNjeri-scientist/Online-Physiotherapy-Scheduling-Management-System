/*CREATE DATABASE physiomanagement;*/
use physiomanagement;

CREATE TABLE `patient` (
  `patient_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `county` varchar(255) NOT NULL,
  `town_or_city` varchar(15) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`patient_id`),
  UNIQUE KEY `phone_number` (`phone_number`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DESCRIBE patient;

CREATE TABLE `patient_issues` (
  `patient_issues_id` int NOT NULL AUTO_INCREMENT,
  `schedules_id` int DEFAULT NULL,
  `issue` text,
  PRIMARY KEY (`patient_issues_id`),
  KEY `schedules_id` (`schedules_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DESCRIBE patient_issues;

CREATE TABLE `physio` (
  `physio_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `registration_id` varchar(255) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `qualification` varchar(255) DEFAULT NULL,
  `address` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`physio_id`),
  UNIQUE KEY `phone_number` (`phone_number`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DESCRIBE physio;

CREATE TABLE `recommendation` (
  `recommendation_id` int NOT NULL AUTO_INCREMENT,
  `schedules_id` int DEFAULT NULL,
  `recommendation` text NOT NULL,
  `prescription` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`recommendation_id`),
  KEY `schedules_id` (`schedules_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DESCRIBE recommendation;

CREATE TABLE `schedules` (
  `schedules_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL DEFAULT '0',
  `physio_id` int NOT NULL DEFAULT '0',
  `serial_no` varchar(30) DEFAULT NULL,
  `payment` varchar(50) DEFAULT '0',
  `status` int NOT NULL DEFAULT '0',
  `time_slot_start` timestamp NULL DEFAULT NULL,
  `time_slot_end` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`schedules_id`),
  UNIQUE KEY `serial_no` (`serial_no`),
  KEY `physio_id` (`physio_id`),
  KEY `patient_id` (`patient_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DESCRIBE schedules;

CREATE TABLE `system_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identification` varchar(255) DEFAULT NULL,
  `status` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DESCRIBE system_logs;

CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DESCRIBE users;