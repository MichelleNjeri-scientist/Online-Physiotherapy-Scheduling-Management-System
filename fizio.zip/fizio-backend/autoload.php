<?php

// Define a function called 'autoload' that takes a class name as a parameter
function autoload($class){
    // Include the class file by appending the class name to the 'controllers/' directory path
    include 'controllers/'.$class.'.php';
}

// Register the 'autoload' function with the PHP autoloader
spl_autoload_register('autoload');

// Create a new instance of the 'DB' class and assign it to the variable 'database'
$database = new DB();
// Create a new instance of the 'logActivity' class and assign it to the variable 'log'
$log = new logActivity();

// Establish a database connection by calling the 'getConnection' method on the 'database' instance, and assign the connection to the variable 'db'
$db = $database->getConnection();

// Create new instances of various classes used in the application, passing the 'db' connection as a parameter to each constructor
$functions = new Functions();
$users = new Users($db, $log);
$physios = new Physios($db);
$physio_schedules = new PhysioSchedules($db);
$patients = new Patients($db);
$patient_schedules = new PatientSchedules($db);
$patient_issues = new PatientIssues($db);
$recommendations = new Recommendations($db);
$payments = new Payments($db);
$admins = new Admins($db);
$export = new Export($db);



/* file is responsible for automatically loading classes and files
 when they are needed within the application. It helps simplify
 the process of including class files and eliminates the need for 
 manually including them using require or include statements throughout the codebase.*/