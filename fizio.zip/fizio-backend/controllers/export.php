<?php

class Export {

    public $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function export($patient_id){
        $stmt = $this->conn->prepare('SELECT * FROM schedules  WHERE patient_id='.$patient_id);
        $stmt->execute();
        //$data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $schedules_card = $stmt->rowCount();
        $visited_card = 0;
        $recommendations_card = 0;
        
        $data = array();
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            $arr = array();
            $active_status = 'yet to be booked';
            $active_status_class = "notAssigned";
            //if($row['patient_id'] != '' AND $row['patient_id'] != null){
            if($row['status'] != 0 AND $row['status'] != null){
                $stmt1 = $this->conn->prepare('SELECT * FROM physio WHERE physio_id='.$row['physio_id']);
                $stmt1->execute();
                $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
                $issue = '';
                $recommendation = '';
                $prescription = '';
                
                if(isset($row1['physio_id'])){
                    $active_status = "payment made";
                    $active_status_class = "paid";
                    $status = "This session will be with ".$row1['name']." at ".$row1['address'];
                    
                    $stmt2 = $this->conn->prepare('SELECT * FROM patient_issues WHERE schedules_id='.$row['schedules_id']);
                    $stmt2->execute();
                    $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
                    if(isset($row2['schedules_id'])){
                        $visited_card = $visited_card + 1;
                        $active_status = 'patient visit complete';
                        $active_status_class = "visited";
                        $issue = $row2['issue'];
                    } 

                    $stmt3 = $this->conn->prepare('SELECT * FROM recommendation WHERE schedules_id='.$row['schedules_id']);
                    $stmt3->execute();
                    $row3 = $stmt3->fetch(PDO::FETCH_ASSOC);
                    if(isset($row3['schedules_id'])){
                        $active_status = 'recommendations given';
                        $recommendations_card = $recommendations_card + 1;
                        $active_status_class = "recommendation";
                        $recommendation = $row3['recommendation'];
                        $prescription = $row3['prescription'];
                    }
                }else{
                    $status = "This session has not been booked.";
                }

            }else{
                $status = "This session has not been booked.";
            }
            $arr = array(
                'status' => $status,
                'time_slot_start' => $row['time_slot_start'],
                'time_slot_end' => $row['time_slot_end'],
                'active_status' => $active_status,
                'active_status_class' => $active_status_class,
                'issue' => $issue,
                'recommendation' => $recommendation,
                'prescription' => $prescription
            ); 
            array_push($data, $arr); 
        }
        
        // Create a file pointer
        $file = fopen('exported_data.csv', 'w');
        
        // Write column headers to the CSV file
        $columnHeaders = array('status', 'time slot start', 'time slot end', 'active status', 'active status class', 'issue', 'recommendation', 'prescription');
        fputcsv($file, $columnHeaders);
        
        // Write data rows to the CSV file
        foreach($data as $row) {
            fputcsv($file, $row);
        }
        
        // Close the file pointer
        fclose($file);
        
        // Set headers for the CSV file download
        header('Content-Type: application/csv');
        header('Content-Disposition: attachment; filename="exported_data.csv"');
        
        // Read the file and output it to the browser
        readfile('exported_data.csv');
                     
    }
    
    public function export_all_admin($page_status, $time_slot_start){
        if($time_slot_start == ''){
          $stmt = $this->conn->prepare('SELECT * FROM schedules');
        }else{
          $stmt = $this->conn->prepare('SELECT * FROM schedules  WHERE time_slot_start LIKE "%'.$time_slot_start.'%"');
        }
        $stmt->execute(); 
        $data = array();
        $schedules_card = $stmt->rowCount();
        $visited_card = 0;
        $recommendations_card = 0;

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            $arr = array();
            $active_status = 'yet to be booked';
            $active_status_class = "notAssigned";
            $issue = '';
            $recommendation = '';
            $prescription = '';
            $transaction_id = '';
            $stmtp = $this->conn->prepare('SELECT * FROM physio WHERE physio_id='.$row['physio_id']);
            $stmtp->execute();
            $rowp = $stmtp->fetch(PDO::FETCH_ASSOC);            
            
            //if($row['patient_id'] != '' AND $row['patient_id'] != null){
                if($row['status'] != 0 AND $row['status'] != null){
                    $stmt1 = $this->conn->prepare('SELECT * FROM patient WHERE patient_id='.$row['patient_id']);
                    $stmt1->execute();
                    $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
                    
                    if(isset($row1['patient_id'])){
                        $transaction_id = $row['payment'];
                        $active_status = "payment made";
                        $active_status_class = "paid";
                        $status = "This session has been created by ".$rowp['name']." and booked by ".$row1['name'].". Contact information is : Phone number ".$row1['phone_number']." and Email ".$row1['email'];
                        
                        $stmt2 = $this->conn->prepare('SELECT * FROM patient_issues WHERE schedules_id='.$row['schedules_id']);
                        $stmt2->execute();
                        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
                        if(isset($row2['schedules_id'])){
                            $visited_card = $visited_card + 1;
                            $active_status = 'patient assessment complete';
                            $active_status_class = "visited";
                            $issue = $row2['issue'];
                        } 
    
                        $stmt3 = $this->conn->prepare('SELECT * FROM recommendation WHERE schedules_id='.$row['schedules_id']);
                        $stmt3->execute();
                        $row3 = $stmt3->fetch(PDO::FETCH_ASSOC);
                        if(isset($row3['schedules_id'])){
                            $active_status = 'recommendations given';
                            $recommendations_card = $recommendations_card + 1;
                            $active_status_class = "recommendation";
                            $recommendation = $row3['recommendation'];
                            $prescription = $row3['prescription'];
                        }
                    }else{
                        $status = "This session has been created by ".$rowp['name']." and it has not been booked.";
                    }
    
                }else if($row['patient_id'] != 0 && $row['patient_id'] != null){
                  $stmt1 = $this->conn->prepare('SELECT * FROM patient WHERE patient_id='.$row['patient_id']);
                  $stmt1->execute();
                  $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
                  $stmtp = $this->conn->prepare('SELECT * FROM physio WHERE physio_id='.$row['physio_id']);
                  $stmtp->execute();
                  $rowp = $stmtp->fetch(PDO::FETCH_ASSOC);

                  $active_status = "payment yet to be cleared";
                  $active_status_class = "notAssigned";                
                  $status = "This session has been created by ".$rowp['name']." and has been reserved by ".$row1['name'].". This session's payment is yet to be cleared by the Admin.";
              }else{
                  $active_status = 'yet to be booked';
                  $active_status_class = "notAssigned";                
                  $status = "This session has been created by ".$rowp['name']." and it has not been booked.";
              }
            $arr = array(
                'status' => $status,
                'time_slot_start' => $row['time_slot_start'],
                'time_slot_end' => $row['time_slot_end'],
                'active_status' => $active_status,
                'active_status_class' => $active_status_class,
                'transaction_id' => $transaction_id,
                'issue' => $issue,
                'recommendation' => $recommendation,
                'prescription' => $prescription
            ); 
            if($page_status == $active_status){
              array_push($data, $arr); 
            }else if($page_status == ''){
              array_push($data, $arr); 
            }            
        }
        // Create a file pointer
        $file = fopen('exported_data.csv', 'w');
                
        // Write column headers to the CSV file
        $columnHeaders = array('status', 'time slot start', 'time slot end', 'active status', 'active status class', 'transaction id', 'issue', 'recommendation', 'prescription');
        fputcsv($file, $columnHeaders);

        // Write data rows to the CSV file
        foreach($data as $row) {
            fputcsv($file, $row);
        }

        // Close the file pointer
        fclose($file);

        // Set headers for the CSV file download
        header('Content-Type: application/csv');
        header('Content-Disposition: attachment; filename="exported_data.csv"');

        // Read the file and output it to the browser
        readfile('exported_data.csv');               
    }
    public function export_all_patient($physio_id, $page_status, $time_slot_start){
      if($time_slot_start == ''){
        $stmt = $this->conn->prepare('SELECT * FROM schedules WHERE physio_id='.$physio_id);
      }else{
        $stmt = $this->conn->prepare('SELECT * FROM schedules  WHERE  physio_id='.$physio_id.' AND time_slot_start LIKE "%'.$time_slot_start.'%"');
      }
      $stmt->execute(); 
      $data = array();
      $schedules_card = $stmt->rowCount();
      $visited_card = 0;
      $recommendations_card = 0;

      while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
          $arr = array();
          $active_status = 'yet to be booked';
          $active_status_class = "notAssigned";
          $issue = '';
          $recommendation = '';
          $prescription = '';
          
          //if($row['patient_id'] != '' AND $row['patient_id'] != null){
              if($row['status'] != 0 AND $row['status'] != null){
                  $stmt1 = $this->conn->prepare('SELECT * FROM patient WHERE patient_id='.$row['patient_id']);
                  $stmt1->execute();
                  $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
                  if(isset($row1['patient_id'])){
                      $active_status = "payment made";
                      $active_status_class = "paid";
                      $status = "This session has been booked by ".$row1['name'].". Contact information is : Phone number ".$row1['phone_number']." and Email ".$row1['email'];
                      
                      $stmt2 = $this->conn->prepare('SELECT * FROM patient_issues WHERE schedules_id='.$row['schedules_id']);
                      $stmt2->execute();
                      $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
                      if(isset($row2['schedules_id'])){
                          $visited_card = $visited_card + 1;
                          $active_status = 'patient assessment complete';
                          $active_status_class = "visited";
                          $issue = $row2['issue'];
                      } 
  
                      $stmt3 = $this->conn->prepare('SELECT * FROM recommendation WHERE schedules_id='.$row['schedules_id']);
                      $stmt3->execute();
                      $row3 = $stmt3->fetch(PDO::FETCH_ASSOC);
                      if(isset($row3['schedules_id'])){
                          $active_status = 'recommendations given';
                          $recommendations_card = $recommendations_card + 1;
                          $active_status_class = "recommendation";
                          $recommendation = $row3['recommendation'];
                          $prescription = $row3['prescription'];
                      }
                  }else{
                      $status = "This session has not been booked.";
                  }
  
              }else if($row['patient_id'] != 0 && $row['patient_id'] != null){
                $stmt1 = $this->conn->prepare('SELECT * FROM patient WHERE patient_id='.$row['patient_id']);
                $stmt1->execute();
                $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
                $active_status = "payment yet to be cleared";
                $active_status_class = "notAssigned";                
                $status = "This session has been reserved by ".$row1['name'].". This session's payment is yet to be cleared by the Admin.";
            }else{
                $active_status = 'yet to be booked';
                $active_status_class = "notAssigned";                
                $status = "This session has not been booked.";
            }
          $arr = array(
              'status' => $status,
              'time_slot_start' => $row['time_slot_start'],
              'time_slot_end' => $row['time_slot_end'],
              'active_status' => $active_status,
              'active_status_class' => $active_status_class,
              'issue' => $issue,
              'recommendation' => $recommendation,
              'prescription' => $prescription
          ); 
          if($page_status == $active_status){
            array_push($data, $arr); 
          }else if($page_status == ''){
            array_push($data, $arr); 
          }                        
      }
      // Create a file pointer
      $file = fopen('exported_data.csv', 'w');
              
      // Write column headers to the CSV file
      $columnHeaders = array('status', 'time slot start', 'time slot end', 'active status', 'active status class', 'issue', 'recommendation', 'prescription');
      fputcsv($file, $columnHeaders);

      // Write data rows to the CSV file
      foreach($data as $row) {
          fputcsv($file, $row);
      }

      // Close the file pointer
      fclose($file);

      // Set headers for the CSV file download
      header('Content-Type: application/csv');
      header('Content-Disposition: attachment; filename="exported_data.csv"');

      // Read the file and output it to the browser
      readfile('exported_data.csv');               
  }
    public function export_one($patient_id){
        $stmt = $this->conn->prepare('SELECT * FROM schedules WHERE patient_id='.$patient_id);
        $stmt->execute(); 
        $data = array();
        $schedules_card = $stmt->rowCount();
        $visited_card = 0;
        $recommendations_card = 0;

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            $arr = array();
            $active_status = 'yet to be booked';
            $active_status_class = "notAssigned";
            $issue = '';
            $recommendation = '';
            $prescription = '';
            
            //if($row['patient_id'] != '' AND $row['patient_id'] != null){
                if($row['status'] != 0 AND $row['status'] != null){
                    $stmt1 = $this->conn->prepare('SELECT * FROM patient WHERE patient_id='.$row['patient_id']);
                    $stmt1->execute();
                    $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
                    if(isset($row1['patient_id'])){
                        $active_status = "payment made";
                        $active_status_class = "paid";
                        $status = "This session has been booked by ".$row1['name'].". Contact information is : Phone number ".$row1['phone_number']." and Email ".$row1['email'];
                        
                        $stmt2 = $this->conn->prepare('SELECT * FROM patient_issues WHERE schedules_id='.$row['schedules_id']);
                        $stmt2->execute();
                        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
                        if(isset($row2['schedules_id'])){
                            $visited_card = $visited_card + 1;
                            $active_status = 'patient assessment complete';
                            $active_status_class = "visited";
                            $issue = $row2['issue'];
                        } 
    
                        $stmt3 = $this->conn->prepare('SELECT * FROM recommendation WHERE schedules_id='.$row['schedules_id']);
                        $stmt3->execute();
                        $row3 = $stmt3->fetch(PDO::FETCH_ASSOC);
                        if(isset($row3['schedules_id'])){
                            $active_status = 'recommendations given';
                            $recommendations_card = $recommendations_card + 1;
                            $active_status_class = "recommendation";
                            $recommendation = $row3['recommendation'];
                            $prescription = $row3['prescription'];
                        }
                    }else{
                        $status = "This session has not been booked.";
                    }
    
                }else if($row['patient_id'] != 0 && $row['patient_id'] != null){
                  $stmt1 = $this->conn->prepare('SELECT * FROM patient WHERE patient_id='.$row['patient_id']);
                  $stmt1->execute();
                  $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
                  $active_status = "payment yet to be cleared";
                  $active_status_class = "notAssigned";                
                  $status = "This session has been reserved by ".$row1['name'].". This session's payment is yet to be cleared by the Admin.";
              }else{
                  $active_status = 'yet to be booked';
                  $active_status_class = "notAssigned";                
                  $status = "This session has not been booked.";
              }
            $arr = array(
                'status' => $status,
                'time_slot_start' => $row['time_slot_start'],
                'time_slot_end' => $row['time_slot_end'],
                'active_status' => $active_status,
                'active_status_class' => $active_status_class,
                'issue' => $issue,
                'recommendation' => $recommendation,
                'prescription' => $prescription
            ); 
            array_push($data, $arr);             
        }
        // Create a file pointer
        $file = fopen('exported_data.csv', 'w');
                
        // Write column headers to the CSV file
        $columnHeaders = array('status', 'time slot start', 'time slot end', 'active status', 'active status class', 'issue', 'recommendation', 'prescription');
        fputcsv($file, $columnHeaders);

        // Write data rows to the CSV file
        foreach($data as $row) {
            fputcsv($file, $row);
        }

        // Close the file pointer
        fclose($file);

        // Set headers for the CSV file download
        header('Content-Type: application/csv');
        header('Content-Disposition: attachment; filename="exported_data.csv"');

        // Read the file and output it to the browser
        readfile('exported_data.csv');          
    }
}
?>