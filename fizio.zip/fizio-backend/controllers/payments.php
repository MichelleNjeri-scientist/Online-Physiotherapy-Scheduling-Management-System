<?php

class Payments {

    public $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function view($page){
        
        // get total number of rows in the table
        $stmt = $this->conn->prepare('SELECT COUNT(*) FROM mobile_payments');
        $stmt->execute();
        $totalRows = $stmt->fetchColumn();
        
        // calculate total number of pages based on rows per page
        $rowsPerPage = 5;
        $totalPages = ceil($totalRows / $rowsPerPage);
        
        // get current page number and calculate offset
        $pageNumber = isset($_GET['page']) ? $_GET['page'] : 1;
        $offset = ($page - 1) * $rowsPerPage;
        
        // retrieve data for the current page
        $stmt = $this->conn->prepare('SELECT * FROM mobile_payments LIMIT ?, ?');
        $stmt->bindParam(1, $offset, PDO::PARAM_INT);
        $stmt->bindParam(2, $rowsPerPage, PDO::PARAM_INT);
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // return data in JSON format
        return json_encode([
          'totalPages' => $totalPages,
          'data' => $data
        ]);
    }

    public function add($TransactionType, $TransID, $TransTime, $TransAmount, $BusinessShortCode, $BillRefNumber, $InvoiceNumber, $OrgAccountBalance, $ThirdPartyTransID, $MSISDN, $FirstName, $MiddleName, $LastName){
        $stmt = $this->conn->prepare('INSERT INTO mobile_payments (TransactionType, TransID, TransTime, TransAmount, BusinessShortCode, BillRefNumber, InvoiceNumber, OrgAccountBalance, ThirdPartyTransID, MSISDN, FirstName, MiddleName, LastName) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([$TransactionType, $TransID, $TransTime, $TransAmount, $BusinessShortCode, $BillRefNumber, $InvoiceNumber, $OrgAccountBalance, $ThirdPartyTransID, $MSISDN, $FirstName, $MiddleName, $LastName]);

        return json_encode([
            'data' => 'success',
          ]);
    }

    public function edit($payment_id, $TransactionType, $TransID, $TransTime, $TransAmount, $BusinessShortCode, $BillRefNumber, $InvoiceNumber, $OrgAccountBalance, $ThirdPartyTransID, $MSISDN, $FirstName, $MiddleName, $LastName){
        $stmt = $this->conn->prepare('UPDATE mobile_payments SET TransactionType=?, TransID=?, TransTime=?, TransAmount=?, BusinessShortCode=?, BillRefNumber=?, InvoiceNumber=?, OrgAccountBalance=?, ThirdPartyTransID=?, MSISDN=?, FirstName=?, MiddleName=?, LastName=?  WHERE payment_id='.$payment_id);
        $stmt->execute([$TransactionType, $TransID, $TransTime, $TransAmount, $BusinessShortCode, $BillRefNumber, $InvoiceNumber, $OrgAccountBalance, $ThirdPartyTransID, $MSISDN, $FirstName, $MiddleName, $LastName]);

        return json_encode([
            'data' => 'success',
          ]);
    }

    public function delete($payment_id){
        $stmt = $this->conn->prepare('DELETE FROM mobile_payments WHERE payment_id='.$payment_id);
        $stmt->execute();

        return json_encode([
            'data' => 'success',
        ]);
    }

    public function payment_check($payment){
        $stmt = $this->conn->prepare('SELECT * FROM schedules WHERE payment="'.$payment.'"');
        $stmt->execute();
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        if(isset($row['payment'])){
            return json_encode([
                'success' => 2,
            ]);
        }else{
            return json_encode([
                'success' => 1,
            ]);            
        } 
    }

    public function payment_confirm($payment1, $schedules_id){
        if($payment1 != null || $payment1 != ''){
            $stmt = $this->conn->prepare('SELECT * FROM schedules WHERE payment="'.$payment1.'"');
            $stmt->execute();
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
            if(isset($row['payment'])){
                return json_encode([
                    'success' => 2,
                ]);
            }else{
                $stmt2 = $this->conn->prepare('UPDATE schedules SET payment = ?, status = ? WHERE schedules_id = '. $schedules_id);
                $stmt2->execute([$payment1, 1]);
                                
                return json_encode([
                    'success' => 1,
                ]);            
            } 
        }else{
            $stmt2 = $this->conn->prepare('UPDATE schedules SET status = ? WHERE schedules_id = '. $schedules_id);
            $stmt2->execute([1]);
                            
            return json_encode([
                'success' => 1,
            ]);       
        }
    }

}