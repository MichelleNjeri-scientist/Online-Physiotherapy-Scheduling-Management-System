<?php

class PatientIssues {

    public $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function view($page, $patient_id){
        
        // get total number of rows in the table
        $stmt = $this->conn->prepare('SELECT COUNT(*) FROM patient_issues WHERE patient_id=?');
        $stmt->execute([$patient_id]);
        $totalRows = $stmt->fetchColumn();
        
        // calculate total number of pages based on rows per page
        $rowsPerPage = 5;
        $totalPages = ceil($totalRows / $rowsPerPage);
        
        // get current page number and calculate offset
        $pageNumber = isset($_GET['page']) ? $_GET['page'] : 1;
        $offset = ($page - 1) * $rowsPerPage;
        
        // retrieve data for the current page
        $stmt = $this->conn->prepare('SELECT * FROM patient_issues  WHERE patient_id='.$patient_id.'  LIMIT ?, ?');
        $stmt->bindParam(1, $offset, PDO::PARAM_INT);
        $stmt->bindParam(2, $rowsPerPage, PDO::PARAM_INT);
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // return data in JSON format
        return json_encode([
          'totalPages' => $totalPages,
          'data' => $data
        ]);
    }

    public function single($schedules_id){
        $stmt = $this->conn->prepare('SELECT * FROM patient_issues WHERE schedules_id=?');
        $stmt->execute([$schedules_id]);
        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        return json_encode([
            'data' => $data,
          ]);
    }

    public function add($schedules_id, $issue){
        $stmt = $this->conn->prepare('INSERT INTO patient_issues (schedules_id, issue) VALUES (?, ?)');
        $stmt->execute([$schedules_id, $issue]);
        $data = 'success';
        return $data;
    } 
    
    public function edit($schedules_id, $issue){
        $stmt = $this->conn->prepare('SELECT * FROM patient_issues WHERE schedules_id=?');
        $stmt->execute([$schedules_id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if(isset($row['patient_issues_id'])){
            $stmt1 = $this->conn->prepare('UPDATE patient_issues SET schedules_id=?, issue=? WHERE schedules_id='.$schedules_id);
            $stmt1->execute([$schedules_id, $issue]);
            return json_encode([
                'data' => 'success',
            ]);            
        }else{
            return json_encode([
                'data' => $this->add($schedules_id, $issue),
            ]);            
        }
       
    }

}