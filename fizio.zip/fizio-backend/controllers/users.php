<?php

class Users {

    public $conn;
    public $log;

    public function __construct($db, $log) {
        $this->conn = $db;
        $this->log = $log;
    }

    public function auth($email, $password, $user_type) {
        date_default_timezone_set('Africa/Nairobi');
        $currentDateTime = date('Y-m-d H:i:s');      
        $json = [];
        $stmt = $this->conn->prepare("SELECT user_id, email, username, password FROM users WHERE email=? AND user_type=?");
        $stmt->execute([$email, $user_type]);
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            if(password_verify($password, $row['password'])){
                if($user_type == '1'){
                    $stmt1 = $this->conn->prepare('SELECT * FROM physio WHERE email="'.$row['email'].'"');
                    $stmt1->execute();
                    $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
                    $user_id = $row1['physio_id'];                
                }else if($user_type == '2'){
                    $stmt2 = $this->conn->prepare('SELECT * FROM patient WHERE email="'.$row['email'].'"');
                    $stmt2->execute();
                    $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
                    $user_id = $row2['patient_id'];                     
                }else if($user_type == '3'){
                    $user_id = $row['user_id'];                     
                } 
                $this->log->logA($row['email'], 'The user has logged in successfully at '.$currentDateTime);                                
                $json['id'] = $user_id;
                $json['email'] = $row['email'];
                $json['username'] = $row['username'];

                $identification = 'email:  '.$row['email'];
                $status = 'The user has logged in successfully at '.$currentDateTime;
                $stmt4 = $this->conn->prepare('INSERT INTO system_logs (identification, status) VALUES (?,?)');
                $stmt4->execute([$identification, $status]);                
                return json_encode($json);
            }else{
                $identification = 'email:  '.$email;
                $status = 'The user has failed to verify their login credentials at '.$currentDateTime;
                $stmt4 = $this->conn->prepare('INSERT INTO system_logs (identification, status) VALUES (?,?)');
                $stmt4->execute([$identification, $status]);   

                $this->log->logA($email, 'The user has failed to verify their login credentials at '.$currentDateTime); 
            }
        }
        return false;
    }
    public function authforgotpassword($email, $user_type){
        date_default_timezone_set('Africa/Nairobi');
        $currentDateTime = date('Y-m-d H:i:s');   
        $rand = rand(1000,10000);// generates a random number between 1000 and 10000
        $stmt = $this->conn->prepare("SELECT user_id, email, username, password FROM users WHERE email=? AND user_type=?");
        $stmt->execute([$email, $user_type]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if(isset($row['user_id'])){
            $stmt = $this->conn->prepare("UPDATE users SET token=".$rand." WHERE email=? AND user_type=?");
            $stmt->execute([$email, $user_type]);
            

            $identification = $email;
            $status = 'The user has initiated renewal of their password at '.$currentDateTime;
            $stmt4 = $this->conn->prepare('INSERT INTO system_logs (identification, status) VALUES (?,?)');
            $stmt4->execute([$identification, $status]);   

            $this->log->logA($email, 'The user has initiated renewal of their password at '.$currentDateTime);

            return json_encode($rand);
        }else{

            $identification = $email;
            $status = 'The user has failed to verify their login credentials at '.$currentDateTime;
            $stmt4 = $this->conn->prepare('INSERT INTO system_logs (identification, status) VALUES (?,?)');
            $stmt4->execute([$identification, $status]); 

            $this->log->logA($email, 'The user has failed to verify their login credentials at '.$currentDateTime); 
        }
        return false;        
    }
    public function authforgotpasswordupdate($token, $password){
        date_default_timezone_set('Africa/Nairobi');
        $currentDateTime = date('Y-m-d H:i:s');   
        $stmt = $this->conn->prepare("SELECT user_id, email, username, password FROM users WHERE token=?");
        $stmt->execute([$token]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if(isset($row['user_id'])){
            $stmt = $this->conn->prepare("UPDATE users SET password=?, token=? WHERE token='".$token."'");
            $stmt->execute([password_hash($password, PASSWORD_DEFAULT), NULL]);            
            

            $identification = $row['email'];
            $status = 'The user has completed the forgot password renewal at '.$currentDateTime;
            $stmt4 = $this->conn->prepare('INSERT INTO system_logs (identification, status) VALUES (?,?)');
            $stmt4->execute([$identification, $status]);  

            $this->log->logA($row['email'], 'The user has completed the forgot password renewal at '.$currentDateTime);

            return json_encode([
                'data' => 'success',
            ]);            
        }else{

            $identification = 'token: '.$token;
            $status = 'The user has failed to verify their forgot password token at '.$currentDateTime;
            $stmt4 = $this->conn->prepare('INSERT INTO system_logs (identification, status) VALUES (?,?)');
            $stmt4->execute([$identification, $status]);  


            $this->log->logA($token, 'The user has failed to verify their forgot password token at '.$currentDateTime); 
        }
        return false;      
    }
    public function systemlogs($page){
        
        // get total number of rows in the table
        $stmt = $this->conn->prepare('SELECT COUNT(*) FROM system_logs');
        $stmt->execute();
        $totalRows = $stmt->fetchColumn();
        
        // calculate total number of pages based on rows per page
        $rowsPerPage = 5;
        $totalPages = ceil($totalRows / $rowsPerPage);
        
        // get current page number and calculate offset
        $pageNumber = isset($_GET['page']) ? $_GET['page'] : 1;
        $offset = ($page - 1) * $rowsPerPage;
        
        // retrieve data for the current page
        $stmt = $this->conn->prepare('SELECT * FROM system_logs ORDER BY id DESC LIMIT ?, ?');
        $stmt->bindParam(1, $offset, PDO::PARAM_INT);
        $stmt->bindParam(2, $rowsPerPage, PDO::PARAM_INT);
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // return data in JSON format
        return json_encode([
          'totalPages' => $totalPages,
          'data' => $data
        ]);        
    }
}