<?php

class PhysioSchedules {

    public $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function view($page, $physio_id, $time_slot_start, $page_status){
        
        // get total number of rows in the table
        if($time_slot_start == ''){
            $stmt = $this->conn->prepare('SELECT COUNT(*) FROM schedules WHERE physio_id=?');
            $stmt->execute([$physio_id]);
        }else{
            $stmt = $this->conn->prepare('SELECT COUNT(*) FROM schedules WHERE physio_id=? AND time_slot_start LIKE "%'.$time_slot_start.'%"');
            $stmt->execute([$physio_id]);
        }
        $totalRows = $stmt->fetchColumn();
        
        // calculate total number of pages based on rows per page
        $rowsPerPage = 5;
        $totalPages = ceil($totalRows / $rowsPerPage);
        
        // get current page number and calculate offset
        //$pageNumber = isset($_GET['page']) ? $_GET['page'] : 1;
        $offset = ($page - 1) * $rowsPerPage; // used in the sql query to limit number of rows per page, by checking the current schedule id that is to be accessed.

        if($time_slot_start == ''){
            $stmt44 = $this->conn->prepare('SELECT * FROM schedules WHERE physio_id='.$physio_id.' ORDER BY time_slot_start DESC');
        }else{
            $stmt44 = $this->conn->prepare('SELECT * FROM schedules WHERE physio_id='.$physio_id.' AND time_slot_start LIKE "%'.$time_slot_start.'%" ORDER BY time_slot_start DESC');
        }
        $stmt44->execute();
        
        $totalRows2 = 0; // is used to confirm the number of rows in the requested sql query, which will be used to determine the total number of pages.
        while($row44 = $stmt44->fetch(PDO::FETCH_ASSOC)){
            $arr = array();
            
            //if($row['patient_id'] != '' AND $row['patient_id'] != null){
            
            if($row44['status'] != 0 AND $row44['status'] != null){
                $stmt1 = $this->conn->prepare('SELECT * FROM patient WHERE patient_id='.$row44['patient_id']);
                $stmt1->execute();
                $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
                
                if(isset($row1['patient_id'])){
                    $active_status = "payment made";

                    $stmt3 = $this->conn->prepare('SELECT * FROM recommendation WHERE schedules_id='.$row44['schedules_id']);
                    $stmt3->execute();
                    $row3 = $stmt3->fetch(PDO::FETCH_ASSOC);
                    if(isset($row3['schedules_id'])){
                        $active_status = 'recommendations given';
                    }
                }else{
                    $active_status = 'yet to be booked';
                }

            }else if($row44['patient_id'] != 0 && $row44['patient_id'] != null){
                $active_status = "payment yet to be cleared";
            }else{
                $active_status = 'yet to be booked';
            }

            if($page_status == $active_status){
                $totalRows2 = $totalRows2 + 1;
            }else if ($page_status == ''){
                $totalRows2 = $totalRows2 + 1;
            }
                      
        }        
        
        // retrieve data for the current page
        
        if($totalRows2 > 5){
            if($time_slot_start == ''){
                $stmt = $this->conn->prepare('SELECT * FROM schedules WHERE physio_id='.$physio_id.' ORDER BY time_slot_start DESC LIMIT ?, ?');
            }else{
                $stmt = $this->conn->prepare('SELECT * FROM schedules WHERE physio_id='.$physio_id.' AND time_slot_start LIKE "%'.$time_slot_start.'%" ORDER BY time_slot_start DESC LIMIT ?, ?');
            }            
            $stmt->bindParam(1, $offset, PDO::PARAM_INT); // (2 - 1) * 5 = 5
            //$stmt->bindParam(1, $pageNumber, PDO::PARAM_INT);
            $stmt->bindParam(2, $rowsPerPage, PDO::PARAM_INT); // offset  = 5 and rows per page 5, row 5 - row 10 according the order set "time_slot_start DESC"
        }else{
            // equal to or less than 5 
            if($time_slot_start == ''){
                $stmt = $this->conn->prepare('SELECT * FROM schedules WHERE physio_id='.$physio_id.' ORDER BY time_slot_start DESC');
            }else{
                $stmt = $this->conn->prepare('SELECT * FROM schedules WHERE physio_id='.$physio_id.' AND time_slot_start LIKE "%'.$time_slot_start.'%" ORDER BY time_slot_start DESC');
            } 
            $totalPages = 1;           
        }
        $stmt->execute();
        //$data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $schedules_card = $stmt->rowCount();
        $booked_card = 0;
        $visited_card = 0;
        $recommendations_card = 0;
        
        $data = array();
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            $arr = array();
            
            //if($row['patient_id'] != '' AND $row['patient_id'] != null){
            $email = 'null';
            if($row['status'] != 0 AND $row['status'] != null){
                $stmt1 = $this->conn->prepare('SELECT * FROM patient WHERE patient_id='.$row['patient_id']);
                $stmt1->execute();
                $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
                
                if(isset($row1['patient_id'])){
                    $active_status = "payment made";
                    $active_status_class = "paid";
                    $booked_card = $booked_card + 1;
                    $status = "This session has been booked by ".$row1['name'].". Contact information is : Phone number ".$row1['phone_number']." and Email ".$row1['email'];
                    $email = $row1['email'];
                    $stmt2 = $this->conn->prepare('SELECT * FROM patient_issues WHERE schedules_id='.$row['schedules_id']);
                    $stmt2->execute();
                    $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
                    if(isset($row2['schedules_id'])){
                        $visited_card = $visited_card + 1;
                        $active_status = 'patient assessment complete';
                        $active_status_class = "visited";
                    } 

                    $stmt3 = $this->conn->prepare('SELECT * FROM recommendation WHERE schedules_id='.$row['schedules_id']);
                    $stmt3->execute();
                    $row3 = $stmt3->fetch(PDO::FETCH_ASSOC);
                    if(isset($row3['schedules_id'])){
                        $active_status = 'recommendations given';
                        $recommendations_card = $recommendations_card + 1;
                        $active_status_class = "recommendation";
                    }
                }else{
                    $active_status = 'yet to be booked';
                    $active_status_class = "notAssigned";                    
                    $status = "This session has not been booked.";
                }

            }else if($row['patient_id'] != 0 && $row['patient_id'] != null){
                $stmt1 = $this->conn->prepare('SELECT * FROM patient WHERE patient_id='.$row['patient_id']);
                $stmt1->execute();
                $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
                $active_status = "payment yet to be cleared";
                $active_status_class = "notAssigned";                
                $status = "This session has been reserved by ".$row1['name'].". This session's payment is yet to be cleared by the Admin.";
            }else{
                $active_status = 'yet to be booked';
                $active_status_class = "notAssigned";                
                $status = "This session has not been booked.";
            }
            $arr = array(
                'email' => $email,
                'schedules_id' => $row['schedules_id'],
                'serial_no' => $row['serial_no'],
                'status' => $status,
                'time_slot_start' => $row['time_slot_start'],
                'time_slot_end' => $row['time_slot_end'],
                'active_status' => $active_status,
                'active_status_class' => $active_status_class,
            ); 
            if($page_status == $active_status){
                array_push($data, $arr);
            }else if ($page_status == ''){
                array_push($data, $arr);
            }
                      
        }
        
        // return data in JSON format
        return json_encode([
          'totalPages' => $totalPages,
          'data' => $data,
          'schedules_card' => $schedules_card,
          'visited_card' => $visited_card,
          'recommendations_card' => $recommendations_card,
          'booked_card' => $booked_card
        ]);
    }

    public function single($schedules_id){
        $stmt = $this->conn->prepare('SELECT * FROM schedules WHERE schedules_id=?');
        $stmt->execute([$schedules_id]);
        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        return json_encode([
            'data' => $data,
          ]);
    }


    public function add($physio_id, $time_slot_start, $time_slot_end){
        $random_string = 'SCH'.mt_rand(100,90000);
        $is_unique_i = false;
        
        while (!$is_unique_i) {
            $stmt = $this->conn->prepare('SELECT * FROM schedules WHERE serial_no='.$random_string);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!isset($result)){
                $is_unique_i = true;
            }   
            else {
                $random_string = 'SCH'.mt_rand(1070,90000);
            }
                
        }

        $stmt = $this->conn->prepare('INSERT INTO schedules (physio_id, time_slot_start, time_slot_end, serial_no) VALUES (?, ?, ?, ?)');
        $stmt->execute([$physio_id, $time_slot_start, $time_slot_end, $random_string]);
        $data = 'success';
        return $data;
    }

    public function edit($schedules_id, $physio_id, $time_slot_start, $time_slot_end){
        $stmt = $this->conn->prepare('SELECT * FROM schedules WHERE schedules_id='.$schedules_id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if(isset($row['schedules_id'])){
            $stmt1 = $this->conn->prepare('UPDATE schedules SET time_slot_start=?, time_slot_end=?  WHERE schedules_id='.$schedules_id);
            $stmt1->execute([$time_slot_start, $time_slot_end]);
    
            return json_encode([
                'data' => 'success',
            ]);
        }else{
            return json_encode([
                'data' => $this->add($physio_id, $time_slot_start, $time_slot_end),
            ]);
        }
        
    }

    public function delete($schedules_id){
        $stmt = $this->conn->prepare('SELECT * FROM schedules WHERE patient_id = 0 AND schedules_id='.$schedules_id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if(isset($row['schedules_id'])){
            $stmt = $this->conn->prepare('DELETE FROM schedules WHERE schedules_id='.$schedules_id);
            $stmt->execute();
    
            return json_encode([
                'data' => 'success',
            ]);
        }else{
            return json_encode([
                'data' => "failed",
            ]);
        }
                
        
    }

    public function calendar($date, $physio_id){
        if($physio_id != 'null'){
            $stmt = $this->conn->prepare('SELECT * FROM schedules WHERE patient_id = 0 AND physio_id=? AND time_slot_start LIKE "%'.$date.'%"');
            $stmt->execute([$physio_id]);            
        }else{
            $stmt = $this->conn->prepare('SELECT * FROM schedules WHERE patient_id = 0 AND time_slot_start LIKE "%'.$date.'%"');
            $stmt->execute();            
        }
        $data = array();
        
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            $time_slot_start = $row['time_slot_start'];
            $time_slot_end = $row['time_slot_end'];
            $timestart = strtotime($time_slot_start);
            $timeend = strtotime($time_slot_end);
            $start = date('H:i:s', $timestart);
            $end = date('H:i:s', $timeend);
            $date_now = date("Y-m-d"); // this format is string comparable
                       
            $arr = array(
                'schedules_id' => $row['schedules_id'],
                'date' => $date,
                'time' => $start.' - '.$end
            );
            if ($date_now <= $date) {
                array_push($data, $arr);
            }
        }

        return json_encode([
            'data' => $data,
        ]);
    }

    public function all_patients($physio_id){
        $stmt = $this->conn->prepare('SELECT * FROM schedules WHERE physio_id=? GROUP BY patient_id');
        $stmt->execute([$physio_id]);
        
        $data = array();

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            if($row['patient_id'] != '' || $row['patient_id'] != 0){
                $stmt1 = $this->conn->prepare('SELECT * FROM patient WHERE patient_id=?');
                $stmt1->execute([$row['patient_id']]); 
                $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);

                if(isset($row1['patient_id'])){
                    $arr = array(
                        'patient_id' => $row1['patient_id'],
                        'name' => $row1['name'],
                        'phone_number' => $row1['phone_number'],
                        'email' => $row1['email'],
                        'gender' => $row1['gender'],
                        'county' => $row1['county'],
                        'town_or_city' => $row1['town_or_city'],
                    );
    
                    array_push($data, $arr);                    
                }

            }
        } 

        return json_encode([
            'data' => $data,
        ]);              
    }
}