<?php
// Function to log user activity
class LogActivity {
    function logA($email, $activity) {
        $logFile = 'activity.log';
    
        // Format the log entry
        $logEntry = "[" . date('Y-m-d H:i:s') . "] Email: $email - $activity\n";
    
        // Open the log file in append mode
        $fileHandle = fopen($logFile, 'a');
    
        // Write the log entry to the file with a newline character
        fwrite($fileHandle, $logEntry . PHP_EOL);
    
        // Close the file
        fclose($fileHandle);
    }    
}
?>