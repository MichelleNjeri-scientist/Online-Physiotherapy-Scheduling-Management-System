<?php

class PatientSchedules {

    public $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function view($page, $patient_id){
        
        // get total number of rows in the table
        $stmt = $this->conn->prepare('SELECT COUNT(*) FROM schedules WHERE patient_id=?');
        $stmt->execute([$patient_id]);
        $totalRows = $stmt->fetchColumn();
        
        // calculate total number of pages based on rows per page
        $rowsPerPage = 5;
        $totalPages = ceil($totalRows / $rowsPerPage);
        
        // get current page number and calculate offset
        $pageNumber = isset($_GET['page']) ? $_GET['page'] : 1;
        $offset = ($page - 1) * $rowsPerPage;
        
        // retrieve data for the current page
        $stmt = $this->conn->prepare('SELECT * FROM schedules  WHERE patient_id='.$patient_id.' ORDER BY time_slot_start DESC LIMIT ?, ?');
        $stmt->bindParam(1, $offset, PDO::PARAM_INT);
        $stmt->bindParam(2, $rowsPerPage, PDO::PARAM_INT);
        $stmt->execute();
        //$data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $schedules_card = $stmt->rowCount();
        $visited_card = 0;
        $recommendations_card = 0;
        
        $data = array();
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            $arr = array();
            $active_status = 'yet to be booked';
            $active_status_class = "notAssigned";
            //if($row['patient_id'] != '' AND $row['patient_id'] != null){
            if($row['status'] != 0 AND $row['status'] != null){
                $stmt1 = $this->conn->prepare('SELECT * FROM physio WHERE physio_id='.$row['physio_id']);
                $stmt1->execute();
                $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
                if(isset($row1['physio_id'])){
                    $active_status = "payment made";
                    $active_status_class = "paid";
                    $status = "This session will be with ".$row1['name']." at ".$row1['address'];
                    
                    $stmt2 = $this->conn->prepare('SELECT * FROM patient_issues WHERE schedules_id='.$row['schedules_id']);
                    $stmt2->execute();
                    $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
                    if(isset($row2['schedules_id'])){
                        $visited_card = $visited_card + 1;
                        $active_status = 'patient visit complete';
                        $active_status_class = "visited";
                    } 

                    $stmt3 = $this->conn->prepare('SELECT * FROM recommendation WHERE schedules_id='.$row['schedules_id']);
                    $stmt3->execute();
                    $row3 = $stmt3->fetch(PDO::FETCH_ASSOC);
                    if(isset($row3['schedules_id'])){
                        $active_status = 'recommendations given';
                        $recommendations_card = $recommendations_card + 1;
                        $active_status_class = "recommendation";
                    }
                }else{
                    $status = "This session has not been booked.";
                    $active_status_class = "notAssigned"; 
                }

            }else if($row['patient_id'] != 0 && $row['patient_id'] != null){
              $stmt1 = $this->conn->prepare('SELECT * FROM physio WHERE physio_id='.$row['physio_id']);
              $stmt1->execute();
              $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
              $active_status = "payment yet to be cleared";
              $active_status_class = "notAssigned";                
              $status = "This session has been reserved with ".$row1['name'].". This session's payment is yet to be cleared by the Admin.";
          }else{
                $status = "This session has not been booked.";
            }
            $arr = array(
                'schedules_id' => $row['schedules_id'],
                'serial_no' => $row['serial_no'],
                'status' => $status,
                'time_slot_start' => $row['time_slot_start'],
                'time_slot_end' => $row['time_slot_end'],
                'active_status' => $active_status,
                'active_status_class' => $active_status_class,
            ); 
            array_push($data, $arr);          
        }
        
        // return data in JSON format
        return json_encode([
          'totalPages' => $totalPages,
          'data' => $data
        ]);
    }

    public function book($patient_id, $schedules_id, $payment_status){
        $stmt = $this->conn->prepare('UPDATE schedules SET patient_id=?, payment_status=?  WHERE schedules_id='.$schedules_id);
        $stmt->execute([$patient_id, $payment_status]);

        return json_encode([
            'data' => 'success',
          ]);
    }

}