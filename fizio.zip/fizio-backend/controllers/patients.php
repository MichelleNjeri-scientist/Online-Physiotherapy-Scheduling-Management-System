<?php

class Patients {

    public $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function view($page){
        
        // get total number of rows in the table
        $stmt = $this->conn->prepare('SELECT COUNT(*) FROM patient');
        $stmt->execute();
        $totalRows = $stmt->fetchColumn();
        
        // calculate total number of pages based on rows per page
        $rowsPerPage = 1;
        $totalPages = ceil($totalRows / $rowsPerPage);
        
        // get current page number and calculate offset
        $pageNumber = isset($_GET['page']) ? $_GET['page'] : 1;
        $offset = ($page - 1) * $rowsPerPage;
        
        // retrieve data for the current page
        $stmt = $this->conn->prepare('SELECT * FROM patient LIMIT ?, ?');
        $stmt->bindParam(1, $offset, PDO::PARAM_INT);
        $stmt->bindParam(2, $rowsPerPage, PDO::PARAM_INT);
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // return data in JSON format
        return json_encode([
          'totalPages' => $totalPages,
          'data' => $data
        ]);
    }

    public function add($name, $phone_number, $email, $gender, $county, $town_or_city, $schedules_id, $password, $payment){
        $created_at = date("Y-m-d H:i:s");
        $updated_at = date("Y-m-d H:i:s");
        $stmt = $this->conn->prepare('INSERT INTO patient (name, phone_number, email, gender, county, town_or_city, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)');
        $stmt->execute([$name, $phone_number, $email, $gender, $county, $town_or_city, $created_at, $updated_at]);
        
        $username = $name;
        $user_type = 2;
        $stmt4 = $this->conn->prepare('INSERT INTO users (username, email, password, user_type, created_at, updated_at) VALUES (?,?,?,?,?,?)');
        $stmt4->execute([$username, $email, password_hash($password, PASSWORD_DEFAULT), $user_type, $created_at, $updated_at]);

        $stmt1 = $this->conn->prepare('SELECT * FROM schedules WHERE schedules_id='.$schedules_id);
        $stmt1->execute();
        $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);

        if(isset($row1['schedules_id'])){
            $stmt3 = $this->conn->prepare('SELECT * FROM patient WHERE email="'.$email.'"');
            $stmt3->execute();
            $row3 = $stmt3->fetch(PDO::FETCH_ASSOC);            
            $stmt2 = $this->conn->prepare('UPDATE schedules SET payment=?, patient_id=?  WHERE schedules_id='.$schedules_id);
            $stmt2->execute([$payment, $row3["patient_id"]]);
    
            return json_encode([
                'success' => 1,
            ]);
        }        

        return json_encode([
            'success' => 2,
        ]);
    } 
    
    public function add_payment($schedules_id, $email, $payment){
        $stmt1 = $this->conn->prepare('SELECT * FROM schedules WHERE schedules_id='.$schedules_id);
        $stmt1->execute();
        $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
        $updated_at = date("Y-m-d H:i:s");

        if(isset($row1['schedules_id'])){
            $stmt3 = $this->conn->prepare('SELECT * FROM patient WHERE email="'.$email.'"');
            $stmt3->execute();
            $row3 = $stmt3->fetch(PDO::FETCH_ASSOC);            
            $stmt2 = $this->conn->prepare('UPDATE schedules SET payment=?, patient_id=?  WHERE schedules_id='.$schedules_id);
            $stmt2->execute([$payment, $row3["patient_id"]]);
    
            return json_encode([
                'success' => 1,
            ]);
        }        

        return json_encode([
            'success' => 2,
        ]);
    }

    public function email_check($email){
        $stmt = $this->conn->prepare('SELECT email FROM users WHERE email=? AND user_type = 2');
        $stmt->execute([$email]);  
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        if(isset($row['email']))
        {
            return json_encode([
                'success' => 1,
            ]);
        }else{
            return json_encode([
                'success' => 2,
            ]);
        }  
    }

}