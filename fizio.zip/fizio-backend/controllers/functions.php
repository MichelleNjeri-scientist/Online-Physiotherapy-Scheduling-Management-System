<?php

class Functions {
    public $page;

    public function __construct(){
        $url =(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        /*
        This code creates a URL string that contains the protocol (either "http" or "https"), the server name, and the current request URI.

        Here's a breakdown of how it works:

        isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' checks whether the "HTTPS" server variable is set and its value is "on". If it is, then the protocol should be "https"; otherwise, it should be "http".
        "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]" concatenates the rest of the URL, which consists of the server name and the current request URI. $_SERVER['HTTP_HOST'] contains the server name, and $_SERVER['REQUEST_URI'] contains the path and query string of the current request. The "://" is added between the protocol and the server name to form a complete URL.
        The resulting URL string will have the format: protocol://server-name/path?query-string        
        */

        $this->page = parse_url($url, PHP_URL_PATH);
    }

    public function getPage(){
        return $this->page;
    }
}