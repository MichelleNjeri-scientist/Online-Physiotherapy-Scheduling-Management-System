<?php

class Admins {

    public $conn;

    public function __construct($db) {
        $this->conn = $db;
    }
    public function view_schedules($page, $page_status, $time_slot_start){
        
        // get total number of rows in the table
        if($time_slot_start == ''){
            $stmt = $this->conn->prepare('SELECT COUNT(*) FROM schedules');
            $stmt->execute();
        }else{
            $stmt = $this->conn->prepare('SELECT COUNT(*) FROM schedules WHERE time_slot_start LIKE "%'.$time_slot_start.'%"');
            $stmt->execute();
        }
        $totalRows = $stmt->fetchColumn();
        
        // calculate total number of pages based on rows per page
        $rowsPerPage = 5;
        $totalPages = ceil($totalRows / $rowsPerPage);
        
        // get current page number and calculate offset
        //$pageNumber = isset($_GET['page']) ? $_GET['page'] : 1;
        $offset = ($page - 1) * $rowsPerPage;

        if($time_slot_start == ''){
            $stmt44 = $this->conn->prepare('SELECT * FROM schedules ORDER BY time_slot_start DESC');
        }else{
            $stmt44 = $this->conn->prepare('SELECT * FROM schedules WHERE time_slot_start LIKE "%'.$time_slot_start.'%" ORDER BY time_slot_start DESC');
        }
        $stmt44->execute();
        
        $totalRows2 = 0;
        while($row44 = $stmt44->fetch(PDO::FETCH_ASSOC)){
            $arr = array();
            
            //if($row['patient_id'] != '' AND $row['patient_id'] != null){
            
            if($row44['status'] != 0 AND $row44['status'] != null){
                $stmt1 = $this->conn->prepare('SELECT * FROM patient WHERE patient_id='.$row44['patient_id']);
                $stmt1->execute();
                $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
                
                if(isset($row1['patient_id'])){
                    $active_status = "payment made";

                    $stmt3 = $this->conn->prepare('SELECT * FROM recommendation WHERE schedules_id='.$row44['schedules_id']);
                    $stmt3->execute();
                    $row3 = $stmt3->fetch(PDO::FETCH_ASSOC);
                    if(isset($row3['schedules_id'])){
                        $active_status = 'recommendations given';
                    }
                }else{
                    $active_status = 'yet to be booked';
                }

            }else if($row44['patient_id'] != 0 && $row44['patient_id'] != null){
                $active_status = "payment yet to be cleared";
            }else{
                $active_status = 'yet to be booked';
            }

            if($page_status == $active_status){
                $totalRows2 = $totalRows2 + 1;
            }else if ($page_status == ''){
                $totalRows2 = $totalRows2 + 1;
            }
                      
        }        
        
        // retrieve data for the current page
        
        if($totalRows2 > 5){
            if($time_slot_start == ''){
                $stmt = $this->conn->prepare('SELECT * FROM schedules ORDER BY time_slot_start DESC LIMIT ?, ?');
            }else{
                $stmt = $this->conn->prepare('SELECT * FROM schedules WHERE time_slot_start LIKE "%'.$time_slot_start.'%" ORDER BY time_slot_start DESC LIMIT ?, ?');
            }            
            $stmt->bindParam(1, $offset, PDO::PARAM_INT);
            //$stmt->bindParam(1, $pageNumber, PDO::PARAM_INT);
            $stmt->bindParam(2, $rowsPerPage, PDO::PARAM_INT);
        }else{
            if($time_slot_start == ''){
                $stmt = $this->conn->prepare('SELECT * FROM schedules ORDER BY time_slot_start DESC');
            }else{
                $stmt = $this->conn->prepare('SELECT * FROM schedules WHERE time_slot_start LIKE "%'.$time_slot_start.'%" ORDER BY time_slot_start DESC');
            } 
            $totalPages = 1;           
        }
        $stmt->execute();
        //$data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $schedules_card = $stmt->rowCount();
        $booked_card = 0;
        $visited_card = 0;
        $recommendations_card = 0;
        
        $data = array();
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            $arr = array();
            $active_status = 'yet to be booked';
            $active_status_class = "notAssigned";
            $stmtp = $this->conn->prepare('SELECT * FROM physio WHERE physio_id='.$row['physio_id']);
            $stmtp->execute();
            $rowp = $stmtp->fetch(PDO::FETCH_ASSOC);            
            //if($row['patient_id'] != '' AND $row['patient_id'] != null){
            if($row['status'] != 0 AND $row['status'] != null){
                $stmt1 = $this->conn->prepare('SELECT * FROM patient WHERE patient_id='.$row['patient_id']);
                $stmt1->execute();
                $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
                
                if(isset($row1['patient_id'])){
                    $active_status = "payment made";
                    $active_status_class = "paid";
                    $booked_card = $booked_card + 1;
                    $status = "This session has been created by ".$rowp['name']." and booked by ".$row1['name'].". Contact information is : Phone number ".$row1['phone_number']." and Email ".$row1['email'];
                    
                    $stmt2 = $this->conn->prepare('SELECT * FROM patient_issues WHERE schedules_id='.$row['schedules_id']);
                    $stmt2->execute();
                    $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
                    if(isset($row2['schedules_id'])){
                        $visited_card = $visited_card + 1;
                        $active_status = 'patient assessment complete';
                        $active_status_class = "visited";
                    } 

                    $stmt3 = $this->conn->prepare('SELECT * FROM recommendation WHERE schedules_id='.$row['schedules_id']);
                    $stmt3->execute();
                    $row3 = $stmt3->fetch(PDO::FETCH_ASSOC);
                    if(isset($row3['schedules_id'])){
                        $active_status = 'recommendations given';
                        $recommendations_card = $recommendations_card + 1;
                        $active_status_class = "recommendation";
                    }
                }else{
                    $status = "This session has been created by ".$rowp['name']." and it has not been booked.";
                    $active_status_class = "notAssigned";                
                }

            }else if($row['patient_id'] != 0 && $row['patient_id'] != null){
                $stmt1 = $this->conn->prepare('SELECT * FROM patient WHERE patient_id='.$row['patient_id']);
                $stmt1->execute();
                $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
                $active_status = "payment yet to be cleared";
                $active_status_class = "notAssigned";                
                $status = "This session has been created by ".$rowp['name']." and has been reserved by ".$row1['name'].". This session's payment is yet to be cleared by the Admin.";
            }else{
                $status = "This session has been created by ".$rowp['name']." and it has not been booked.";
                $active_status_class = "notAssigned";
            }
            $arr = array(
                'schedules_id' => $row['schedules_id'],
                'serial_no' => $row['serial_no'],
                'status' => $status,
                'payment' => $row['payment'],
                'time_slot_start' => $row['time_slot_start'],
                'time_slot_end' => $row['time_slot_end'],
                'active_status' => $active_status,
                'active_status_class' => $active_status_class,
            ); 
            if($page_status == $active_status){
                array_push($data, $arr); 
            }else if($page_status == ''){
                array_push($data, $arr); 
            }        
        }
        
        // return data in JSON format
        return json_encode([
          'totalPages' => $totalPages,
          'data' => $data,
          'schedules_card' => $schedules_card,
          'visited_card' => $visited_card,
          'recommendations_card' => $recommendations_card,
          'booked_card' => $booked_card
        ]);
    }
}