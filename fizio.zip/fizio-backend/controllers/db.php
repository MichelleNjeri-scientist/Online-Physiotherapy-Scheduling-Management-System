<?php

class DB{
    private $host = 'localhost';
    private $port = '3306';
    private $username = 'root';
    private $password = 'M1sh@1vy';
    private $database_name = 'physiomanagement';

    public $conn;

    public function getConnection() {
        $this->conn = null;

        try {
            $this->conn = new PDO(
                "mysql:host=".$this->host.";
                port=".$this->port.";
                dbname=".$this->database_name,
                $this->username,
                $this->password,
            );
            return $this->conn;
        } catch (PDOException $exception){
             echo "Error: ".$exception->getMessage();
        }
    }
}