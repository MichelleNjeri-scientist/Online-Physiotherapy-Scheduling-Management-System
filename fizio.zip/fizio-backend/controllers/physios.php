<?php

class Physios {

    public $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function view($page){
        
        // get total number of rows in the table
        $stmt = $this->conn->prepare('SELECT COUNT(*) FROM physio');
        $stmt->execute();
        $totalRows = $stmt->fetchColumn();
        
        // calculate total number of pages based on rows per page
        $rowsPerPage = 5;
        $totalPages = ceil($totalRows / $rowsPerPage);
        
        // get current page number and calculate offset
        $pageNumber = isset($_GET['page']) ? $_GET['page'] : 1;
        $offset = ($page - 1) * $rowsPerPage;
        
        // retrieve data for the current page
        $stmt = $this->conn->prepare('SELECT * FROM physio LIMIT ?, ?');
        $stmt->bindParam(1, $offset, PDO::PARAM_INT);
        $stmt->bindParam(2, $rowsPerPage, PDO::PARAM_INT);
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // return data in JSON format
        return json_encode([
          'totalPages' => $totalPages,
          'data' => $data
        ]);
    }

    public function add($name, $registration_id, $phone_number, $email, $gender, $address, $qualification, $password){
        $created_at = date("Y-m-d H:i:s");
        $updated_at = date("Y-m-d H:i:s");
        $stmt = $this->conn->prepare('INSERT INTO physio (name, registration_id, phone_number, email, gender, address, qualification, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)');
        $stmt->execute([$name, $registration_id, $phone_number, $email, $gender, $address, $qualification, $created_at, $updated_at]);
        
        $username = $name;
        $user_type = 1;
        $stmt4 = $this->conn->prepare('INSERT INTO users (username, email, password, user_type, created_at, updated_at) VALUES (?,?,?,?,?,?)');
        $stmt4->execute([$username, $email, password_hash($password, PASSWORD_DEFAULT), $user_type, $created_at, $updated_at]);
        //bcrypt algorithm to hash the physios passwords before storing them in the db -password_hash($password, PASSWORD_DEFAULT)
        return json_encode([
            'data' => 'success',
          ]);
    }

    public function listed(){
        $stmt = $this->conn->prepare('SELECT * FROM physio');
        $stmt->execute();
        $data = array();
        while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)){
            $arr = array(
                'physio_id' => $row['physio_id'],
                'name' => $row['name'],
                'cv' => $row['qualification'],
                'id' => 'physio'.$row['physio_id'],
            );
            array_push($data, $arr);
        }

        return json_encode([
            'data' => $data,
          ]);
    }

    public function single($physio_id){
        $stmt = $this->conn->prepare('SELECT * FROM physio WHERE physio_id = '.$physio_id);
        $stmt->execute();
        $data = $stmt->fetch(\PDO::FETCH_ASSOC);

        return json_encode([
            'data' => $data,
          ]);
    }

    public function edit($physio_id, $name, $registration_id, $phone_number, $email, $gender, $address, $qualification, $password){
        $created_at = date("Y-m-d H:i:s");
        $updated_at = date("Y-m-d H:i:s");
        $stmt = $this->conn->prepare('UPDATE physio SET name=?, registration_id=?, phone_number=?, email=?, gender=?, address=?, qualification=?, updated_at=? WHERE physio_id='.$physio_id);
        $stmt->execute([$name, $registration_id, $phone_number, $email, $gender, $address, $qualification, $updated_at]);
        
        $username = $name;
        $user_type = 1;
        $stmt4 = $this->conn->prepare('UPDATE users SET username=?, email=?, password=?, user_type=?, updated_at=? WHERE email="'.$email.'"');
        $stmt4->execute([$username, $email, password_hash($password, PASSWORD_DEFAULT), $user_type, $updated_at]);
        
        return json_encode([
            'data' => 'success',
          ]);
    }

    public function delete($physio_id){
        $stmt = $this->conn->prepare('SELECT * FROM schedules WHERE physio_id = '.$physio_id);
        $stmt->execute();
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        $stmt1 = $this->conn->prepare('SELECT * FROM physio WHERE physio_id = '.$physio_id);
        $stmt1->execute();
        $row1 = $stmt1->fetch(\PDO::FETCH_ASSOC);
        $email = $row1['email'];

        if(isset($row['physio_id'])){
            return json_encode([
                'data' => "failed",
            ]);
        }else{
            $stmt2 = $this->conn->prepare("DELETE FROM users WHERE email=?");
            $stmt2->execute([$email]);
            $stmt3 = $this->conn->prepare('DELETE FROM physio WHERE physio_id ='.$physio_id);
            $stmt3->execute();

    
            return json_encode([
                'data' => 'success',
            ]);            
        }

    }


}