<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: *');
header('Content-Type: application/json; charset=utf-8');


if(isset($_GET['physio_id']) && isset($_GET['page_status']) && isset($_GET['time_slot_start'])){
    $physio_id = $_GET['physio_id'];
    $page_status = $_GET['page_status'];
    $time_slot_start = $_GET['time_slot_start'];
}

http_response_code(200);
$json = $export->export_all_patient($physio_id, $page_status, $time_slot_start);

exit();