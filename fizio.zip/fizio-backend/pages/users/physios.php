<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: *');
header('Content-Type: application/json; charset=utf-8');

$data = json_decode(file_get_contents('php://input'));

$name = '';
$registration_id = '';
$phone_number = '';
$email = '';
$gender = '';
$qualification = '';
$password = '';
$address = '';

if(isset($data)){
    $name = $data->name;
    $registration_id = $data->registration_id;
    $phone_number = $data->phone_number;
    $email = $data->email;
    $gender = $data->gender;
    $qualification = $data->qualification;
    $password = $data->password;
    $address = $data->address;
}

http_response_code(200);
if($name && $registration_id && $phone_number && $email && $gender && $qualification && $password && $address) {
    $json = $physios->add($name, $registration_id, $phone_number, $email, $gender, $address, $qualification, $password);
    if($json){
        echo $json;
    }else{
        http_response_code(400);
        echo json_encode([
            'error' => true,
            'message' => 'User account cannot be found'
        ]);
    }
}else{
    echo json_encode([
        'error' => true,
        'message' => 'You are missing information'
    ]);  
}

exit();