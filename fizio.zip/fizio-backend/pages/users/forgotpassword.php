<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: *');
header('Content-Type: application/json; charset=utf-8');



$data = json_decode(file_get_contents('php://input'));

$email = '';
$user_type = '';

if(isset($data)){
    $email = $data->email;
    $user_type = $data->user_type;
}

http_response_code(200);
if($email && $user_type){
    $json = $users->authforgotpassword($email, $user_type);
    if($json){
        echo $json;
    }else{
        http_response_code(400);
        echo json_encode([
            'error' => true,
            'message' => 'User account cannot be found'
        ]);
    }
}else{
    echo json_encode([
        'error' => true,
        'message' => 'You are missing information'
    ]);  
}

exit();