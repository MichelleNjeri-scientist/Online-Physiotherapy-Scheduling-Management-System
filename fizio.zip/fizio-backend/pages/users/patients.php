<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: *');
header('Content-Type: application/json; charset=utf-8');

$data = json_decode(file_get_contents('php://input'));

$name = '';
$phone_number = '';
$email = '';
$gender = '';
$county = '';
$town_or_city  = '';
$schedules_id = '';
$password = '';
$payment = '';

if(isset($data)){
    $name = $data->name;
    $phone_number = $data->phone_number;
    $email = $data->email;
    $gender = $data->gender;
    $county = $data->county;
    $town_or_city  = $data->town_or_city;
    $schedules_id = $data->schedules_id;
    $password = $data->password;
    $payment = $data->payment;
}

http_response_code(200);

if($name && $phone_number && $email && $gender && $county && $town_or_city && $schedules_id && $password && $payment){
    $json = $patients->add($name, $phone_number, $email, $gender, $county, $town_or_city, $schedules_id, $password, $payment);
    if($json){
        echo $json;
    }else{
        http_response_code(400);
        echo json_encode([
            'error' => true,
            'message' => 'User account cannot be found'
        ]);
    }
}else{
    echo json_encode([
        'error' => true,
        'message' => 'You are missing information'
    ]);  
}

exit();