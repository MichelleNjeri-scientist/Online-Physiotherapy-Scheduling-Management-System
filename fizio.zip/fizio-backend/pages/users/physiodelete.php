<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: *');
header('Content-Type: application/json; charset=utf-8');


$data = json_decode(file_get_contents('php://input'));



$physio_id = '';

if(isset($data)){
    $physio_id = $data->physio_id;
}

http_response_code(200);
if($physio_id){
    $json = $physios->delete($physio_id);
    if($json){
        echo $json;
    }else{
        http_response_code(400);
        echo json_encode([
            'error' => true,
            'message' => 'This schedule can not be deleted.'
        ]);
    }
}else{
    echo json_encode([
        'error' => true,
        'message' => 'You are missing information'
    ]);  
}

exit();