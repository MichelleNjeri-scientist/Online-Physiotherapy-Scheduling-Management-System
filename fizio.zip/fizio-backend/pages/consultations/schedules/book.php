<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: *');
header('Content-Type: application/json; charset=utf-8');

//$data = json_decode(file_get_contents('php://input'));



$patient_id = 3;
$schedules_id = 1;
$payment_status = 4;


/*if(isset($data)){
    $patient_id = $data->patient_id;
    $schedules_id = $data->schedules_id;
    $payment_status = $data->payment_status;
}*/

http_response_code(200);

if( $patient_id &&
    $schedules_id &&
    $payment_status
){  
    $json = $patient_schedules->book($patient_id, $schedules_id, $payment_status);
    if($json){
        echo $json;
    }else{
        http_response_code(400);
        echo json_encode([
            'error' => true,
            'message' => 'User account cannot be found'
        ]);
    }
}else{
    echo json_encode([
        'error' => true,
        'message' => 'You are missing information'
    ]);  
}

exit();