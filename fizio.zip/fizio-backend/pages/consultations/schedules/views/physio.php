<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: *');
header('Content-Type: application/json; charset=utf-8');


if(isset($_GET['page']) && isset($_GET['physio_id']) && isset($_GET['page_status']) && isset($_GET['time_slot_start'])){
    $page = $_GET['page'];
    $physio_id = $_GET['physio_id'];
    $page_status = $_GET['page_status'];
    $time_slot_start = $_GET['time_slot_start'];
}

http_response_code(200);
if($page && $physio_id){
    $json = $physio_schedules->view($page, $physio_id, $time_slot_start, $page_status);
    if($json){
        echo $json;
    }else{
        http_response_code(400);
        echo json_encode([
            'error' => true,
            'message' => 'User account cannot be found'
        ]);
    }
}else{
    echo json_encode([
        'error' => true,
        'message' => 'You are missing information'
    ]);  
}

exit();