<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: *');
header('Content-Type: application/json; charset=utf-8');

http_response_code(200);
$json = $physios->listed();
if($json){
    echo $json;
}else{
    http_response_code(400);
    echo json_encode([
        'error' => true,
        'message' => 'User account cannot be found'
    ]);
}    

exit();