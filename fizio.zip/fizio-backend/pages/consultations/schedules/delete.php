<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: *');
header('Content-Type: application/json; charset=utf-8');

$data = json_decode(file_get_contents('php://input'));



$physio_id = '';
$time_slot_start = '';
$time_slot_end = '';

if(isset($data)){
    $schedules_id = $data->schedules_id;
}

http_response_code(200);

if( $schedules_id){  
    $json = $physio_schedules->delete($schedules_id);
    if($json){
        echo $json;
    }else{
        http_response_code(400);
        echo json_encode([
            'error' => true,
            'message' => 'User account cannot be found'
        ]);
    }
}else{
    echo json_encode([
        'error' => true,
        'message' => 'You are missing information'
    ]);  
}

exit();