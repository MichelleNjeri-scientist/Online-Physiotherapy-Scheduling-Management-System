<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: *');
header('Content-Type: application/json; charset=utf-8');

$data = json_decode(file_get_contents('php://input'));

$TransactionType = '';
$TransID = '';
$TransTime = '';
$TransAmount = '';
$BusinessShortCode = '';
$BillRefNumber = '';
$InvoiceNumber = '';
$OrgAccountBalance = '';
$ThirdPartyTransID = '';
$MSISDN = '';
$FirstName = '';
$MiddleName = '';
$LastName = '';

if(isset($data)){
    $id = $data->payment_id;
    $TransactionType = $data->TransactionType;
    $TransID = $data->TransID;
    $TransTime = $data->TransTime;
    $TransAmount = $data->TransAmount;
    $BusinessShortCode = $data->BusinessShortCode;
    $BillRefNumber = $data->BillRefNumber;
    $InvoiceNumber = $data->InvoiceNumber;
    $OrgAccountBalance = $data->OrgAccountBalance;
    $ThirdPartyTransID = $data->ThirdPartyTransID;
    $MSISDN = $data->MSISDN;
    $FirstName = $data->FirstName;
    $MiddleName = $data->MiddleName;
    $LastName = $data->LastName;
}

http_response_code(200);
if(
    $payment_id &&
    $TransactionType &&
    $TransID &&
    $TransTime &&
    $TransAmount &&
    $BusinessShortCode &&
    $BillRefNumber &&
    $InvoiceNumber &&
    $OrgAccountBalance &&
    $ThirdPartyTransID &&
    $MSISDN &&
    $FirstName &&
    $MiddleName &&
    $LastName
){
    $json = $payments->add($payment_id, $TransactionType, $TransID, $TransTime, $TransAmount, $BusinessShortCode, $BillRefNumber, $InvoiceNumber, $OrgAccountBalance, $ThirdPartyTransID, $MSISDN, $FirstName, $MiddleName, $LastName);
    if($json){
        echo $json;
    }else{
        http_response_code(400);
        echo json_encode([
            'error' => true,
            'message' => 'User account cannot be found'
        ]);
    }
}else{
    echo json_encode([
        'error' => true,
        'message' => 'You are missing information'
    ]);  
}

exit();