<?php
require_once('autoload.php');


$page = $functions->getPage();
if(file_exists('pages'.$page.'.php')){
    include('pages'.$page.'.php');
}else{
    http_response_code(404);
}
exit();


/*if(isset($_GET['setup']) && $_GET['setup'] == true){
    $database = new DB();
    $db = $database->getConnection();
    $setup = new Setup($db);
    $messages = $setup->createTables();
    foreach($messages as $message){
        echo $message.'<br>';
    }
}else{
    //echo $functions->getPage();
    $page = $functions->getPage();
    if(file_exists('pages'.$page.'.php')){
        include('pages'.$page.'.php');
    }else{
        http_response_code(404);
    }
    exit();
}*/

